import type { Request, Response, NextFunction } from 'express';
import { AdminAuth } from './auth';
import { ROLE_PERMISSIONS, type UserPermission } from './config';

export function getUserPermissions(auth: AdminAuth, username: string): UserPermission | null {
  const user = auth.getUser(username);
  if (!user) return null;
  if (user.permissions) return user.permissions;
  return ROLE_PERMISSIONS[user.role] || null;
}

  declare global {
    namespace Express {
      interface Request {
        adminUser?: {
          username: string;
          role: 'super_master' | 'master' | 'member' | 'user';
          permissions?: UserPermission;
        };
      }
    }
  }

export function authMiddleware(auth: AdminAuth) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (req.path === '/auth/login' || req.path === '/auth/logout' || req.path === '/auth/qq-login' ||
        req.path === '/auth/qq-login-config' || req.path === '/auth/qq-bind' ||
        req.path === '/auth-codes/verify' || req.path === '/auth-codes/bind-qq' ||
        req.path === '/auth-codes/qq-by-openid' || req.path === '/auth-codes/openid-by-qq' ||
        req.path === '/api/auth/login' || req.path === '/api/auth/logout' || req.path === '/api/auth/qq-login' ||
        req.path === '/api/auth/qq-login-config' || req.path === '/api/auth/qq-bind' ||
        req.path === '/api/auth-codes/verify' || req.path === '/api/auth-codes/bind-qq' ||
        req.path === '/api/auth-codes/qq-by-openid' || req.path === '/api/auth-codes/openid-by-qq' ||
        req.path === '/auth/code' || req.path === '/auth/code/verify' ||
        req.path === '/api/auth/code' || req.path === '/api/auth/code/verify' ||
        req.path === '/auth/register' || req.path === '/api/auth/register' ||
        req.path === '/auth/register/send-code' || req.path === '/api/auth/register/send-code' ||
        req.path === '/system/panel-login-status' || req.path === '/api/system/panel-login-status' ||
        req.path === '/health' || req.path === '/api/health' ||
        req.path === '/api/click' || req.path === '/click') {
      next();
      return;
    }

    const WEBUI_PATH = /^\/?(api\/)?plugins\/[^/]+\/webui(\/|$)/;
    if (WEBUI_PATH.test(req.path)) {
      next();
      return;
    }

    const queryToken = typeof req.query.token === 'string' ? req.query.token : '';
    const token = req.cookies?.admin_token || req.headers.authorization?.replace('Bearer ', '') || queryToken;
    if (!token) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }

    const payload = auth.verifyToken(token);
    if (!payload) {
      res.status(401).json({ error: 'Token expired or invalid' });
      return;
    }

    req.adminUser = { username: payload.username, role: payload.role, permissions: getUserPermissions(auth, payload.username) || undefined };
    next();
  };
}

export function requireSuperMaster(req: Request, res: Response, next: NextFunction): void {
  if (req.adminUser?.role !== 'super_master') {
    res.status(403).json({ error: 'Super master only' });
    return;
  }
  next();
}

// 主人及以上（v1.0.42）：超主 / 主人（master）可执行面板手动更新（接收补丁包 / 触发自动更新检查）
export function requireSuperOrMaster(req: Request, res: Response, next: NextFunction): void {
  const r = req.adminUser?.role;
  if (r !== 'super_master' && r !== 'master') {
    res.status(403).json({ error: 'Super master or master only' });
    return;
  }
  next();
}

// 权限点门槛（v1.0.29）：超主恒放行；其他角色按其 permissions 中对应权限点判定
export function requirePerm(perm: keyof UserPermission) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const u = req.adminUser;
    if (!u) { res.status(401).json({ error: 'Unauthorized' }); return; }
    if (u.role === 'super_master') { next(); return; }
    if (u.permissions && (u.permissions as unknown as Record<string, boolean>)[perm] === true) { next(); return; }
    res.status(403).json({ error: '无权限：需要「' + perm + '」权限（请联系超级主人开通）' });
    return;
  };
}
