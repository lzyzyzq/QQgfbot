<?php
if (!defined('PHP_PLUGIN_DATA_DIR')) define('PHP_PLUGIN_DATA_DIR', "/workspace/data/database");
if (!defined('PHP_PLUGIN_BRIDGE_URL')) define('PHP_PLUGIN_BRIDGE_URL', "http://127.0.0.1:3000");
if (!isset($GLOBALS['__PHP_REPLIES'])) $GLOBALS['__PHP_REPLIES'] = array();
ob_start();
register_shutdown_function(function () {
  $__out = (string)ob_get_clean();
  $__replies = array_values(array_filter($GLOBALS['__PHP_REPLIES'] ?? array(), function ($__r) { return $__r !== null; }));
  if (trim($__out) !== '') { echo $__out; }
  elseif (!empty($__replies)) { echo json_encode(array('replies' => $__replies), JSON_UNESCAPED_UNICODE); }
  else { echo '{}'; }
});
// QQ 机器人 PHP 插件辅助函数库
// 由 PHP 插件桥在运行时自动注入到插件源码前，插件文件内可直接调用；
// 插件也可手动 require_once __DIR__.'/php_helpers.php';
// 说明见 /workspace/docs/PHP插件开发文档.md

if (!defined('PHP_HELPERS_LOADED')) {
define('PHP_HELPERS_LOADED', 1);

if (!function_exists('__php_data_dir')) {
function __php_data_dir() {
  $base = defined('PHP_PLUGIN_DATA_DIR') && PHP_PLUGIN_DATA_DIR
    ? PHP_PLUGIN_DATA_DIR
    : (getcwd() . '/data/database');
  if (!is_dir($base)) @mkdir($base, 0777, true);
  return $base;
}
}

if (!function_exists('__php_safe_path')) {
function __php_safe_path($name, $ext = '') {
  $name = str_replace(array('..', '/', '\\', "\0"), '', (string)$name);
  if ($name === '') return '';
  $p = __php_data_dir() . '/' . $name;
  if (strpos(basename($p), '.') === false) $p .= $ext;
  return $p;
}
}

// ================= 数据读写（data/database 目录，自动加 .json） =================

if (!function_exists('读')) {
// 读：读取 JSON 数据；文件不存在或损坏返回 $default
// 用法1：读($name, $default=null) 读整个文件
// 用法2：读($name, $key, $default=null) 读文件内指定键（对象/数组的键）
function 读($name, $key = null, $default = null) {
  if (is_array($key) || is_object($key)) { $default = $key; $key = null; }
  $f = __php_safe_path($name, '.json');
  if (!is_file($f)) return $key === null ? $default : $default;
  $raw = @file_get_contents($f);
  if ($raw === false) return $default;
  $j = json_decode($raw, true);
  if ($key === null) return $j === null ? $raw : $j;
  if (is_array($j) && array_key_exists($key, $j)) return $j[$key];
  return $default;
}
function read_data($name, $key = null, $default = null) { return 读($name, $key, $default); }

// 写：保存 JSON 数据，成功返回 true
// 用法1：写($name, $data) 写整个文件
// 用法2：写($name, $key, $data) 只更新文件内指定键（保留其他键）
function 写($name, $key = null, $data = null) {
  if (is_array($key) || is_object($key)) { $data = $key; $key = null; }
  $f = __php_safe_path($name, '.json');
  if ($f === '') return false;
  if (func_num_args() >= 3) {
    // 三参：键写入
    $existing = array();
    if (is_file($f)) {
      $raw = @file_get_contents($f);
      $j = json_decode($raw, true);
      if (is_array($j)) $existing = $j;
    }
    $existing[$key] = $data;
    $ok = @file_put_contents($f, json_encode($existing, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
    return $ok !== false;
  }
  // 两参：整文件写入（$data 优先，兼容 写($name, $arr) 风格）
  $ok = @file_put_contents($f, json_encode($data === null ? $key : $data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
  return $ok !== false;
}
function write_data($name, $key = null, $data = null) { return func_num_args() >= 3 ? 写($name, $key, $data) : 写($name, $key); }

// 删：删除数据文件
function 删($name) {
  $f = __php_safe_path($name, '.json');
  if ($f === '' || !is_file($f)) return false;
  return @unlink($f);
}
}

// ================= HTTP 请求 =================

if (!function_exists('curl')) {
// curl：HTTP 请求。method: GET/POST/PUT/DELETE；data 为数组时自动 JSON 编码。
// 响应为 JSON 时自动解码为数组，否则返回字符串；失败返回 null
function curl($url, $method = 'GET', $data = null, $timeout = 8) {
  if (!function_exists('curl_init')) return null;
  $ch = curl_init((string)$url);
  curl_setopt_array($ch, array(
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => (int)$timeout,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'qq-bot-php-plugin',
  ));
  $m = strtoupper((string)$method);
  if (in_array($m, array('POST', 'PUT', 'PATCH', 'DELETE'), true)) {
    $body = is_array($data) ? json_encode($data, JSON_UNESCAPED_UNICODE) : (string)$data;
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $m);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
  }
  $res = curl_exec($ch);
  curl_close($ch);
  if ($res === false) return null;
  $j = json_decode($res, true);
  return $j === null ? $res : $j;
}
function http_get($url, $timeout = 8) { return curl($url, 'GET', null, $timeout); }
function http_post($url, $data, $timeout = 8) { return curl($url, 'POST', $data, $timeout); }
}

// ================= 二维码 =================

if (!function_exists('二维码')) {
// 二维码：返回二维码图片 URL（可作回复图片发送）
function 二维码($text, $size = 300) {
  return 'https://api.qrserver.com/v1/create-qr-code/?size=' . (int)$size . 'x' . (int)$size . '&data=' . urlencode((string)$text);
}
function qrcode($text, $size = 300) { return 二维码($text, $size); }
}

// ================= 文本工具 =================

if (!function_exists('域名大写')) {
// 域名大写：域名转大写显示
function 域名大写($domain) { return strtoupper((string)$domain); }
function upper_domain($domain) { return 域名大写($domain); }
}

if (!function_exists('markdown转html')) {
// markdown转html：简易 Markdown → HTML
function markdown转html($md) {
  $s = htmlspecialchars((string)$md, ENT_QUOTES, 'UTF-8');
  $s = preg_replace('/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/', '<a href="$2" target="_blank" rel="nofollow">$1</a>', $s);
  $s = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $s);
  $s = preg_replace('/\*([^*]+)\*/', '<em>$1</em>', $s);
  $s = preg_replace('/^### (.*)$/m', '<h3>$1</h3>', $s);
  $s = preg_replace('/^## (.*)$/m', '<h2>$1</h2>', $s);
  $s = preg_replace('/^# (.*)$/m', '<h1>$1</h1>', $s);
  $s = preg_replace("/\n/", '<br>', $s);
  return $s;
}
function md_to_html($md) { return markdown转html($md); }
}

if (!function_exists('邮箱验证')) {
// 邮箱验证：邮箱格式校验，返回 true/false
function 邮箱验证($email) {
  return filter_var((string)$email, FILTER_VALIDATE_EMAIL) !== false;
}
function is_email($email) { return 邮箱验证($email); }
}

if (!function_exists('html转图')) {
// html转图：把 HTML 渲染为图片。需配置外部渲染服务
// （桥运行时注入常量 PHP_PLUGIN_HTML2IMG_URL，POST {html,width} 返回 {url}）。
// 未配置时返回空字符串
function html转图($html, $width = 800) {
  $svc = defined('PHP_PLUGIN_HTML2IMG_URL') ? PHP_PLUGIN_HTML2IMG_URL : '';
  if ($svc === '') return '';
  $res = curl($svc, 'POST', array('html' => (string)$html, 'width' => (int)$width));
  if (is_array($res) && isset($res['url'])) return $res['url'];
  return '';
}
function html_to_image($html, $width = 800) { return html转图($html, $width); }
}

// ================= 时间/随机 =================

if (!function_exists('当前时间')) {
// 当前时间：北京时间
function 当前时间($fmt = 'Y-m-d H:i:s') { return gmdate($fmt, time() + 8 * 3600); }
function now($fmt = 'Y-m-d H:i:s') { return 当前时间($fmt); }
function 随机数($min = 0, $max = 100) { return mt_rand((int)$min, (int)$max); }
}

// ================= 回复构造 =================

if (!function_exists('回复文本')) {
function 回复文本($content) { return array('type' => 'text', 'content' => (string)$content); }
function 回复图片($url, $fileName = '') { return array('type' => 'image', 'imageUrl' => (string)$url, 'fileName' => (string)$fileName); }
function 回复语音($url, $fileName = '') { return array('type' => 'voice', 'voiceUrl' => (string)$url, 'fileName' => (string)$fileName); }
function 回复按钮($rows, $content = ' ') { return array('type' => 'button', 'rows' => $rows, 'content' => (string)$content); }
function 回复文卡($title, $content, $url = '') { return array('type' => 'infocard', 'title' => (string)$title, 'content' => (string)$content, 'url' => (string)$url); }
}

// ================= 快捷发送（自动累积回复，脚本结束自动输出；有桥接时立即发送，避免耗时脚本超时零回复） =================

if (!function_exists('__php_ctx')) {
// 读取服务端注入的事件上下文（PHP_PLUGIN_TYPE/GROUP_ID/USER_ID/MSG_ID 等环境变量）
function __php_ctx($k) {
  $v = getenv('PHP_PLUGIN_' . (string)$k);
  return $v !== false ? (string)$v : '';
}
// POST JSON（file_get_contents 回退，供服务器未装 php-curl 扩展时使用），成功返回解码数组/字符串，失败 null
function __php_post_json($url, $data, $timeout = 30) {
  if ((string)$url === '' || !(bool)ini_get('allow_url_fopen')) return null;
  $body = is_array($data) ? json_encode($data, JSON_UNESCAPED_UNICODE) : (string)$data;
  $ctx = stream_context_create(array(
    'http' => array(
      'method' => 'POST',
      'header' => "Content-Type: application/json\r\n",
      'content' => $body,
      'timeout' => max(3, (int)$timeout),
      'ignore_errors' => true,
    ),
    'ssl' => array('verify_peer' => false, 'verify_peer_name' => false),
  ));
  $res = @file_get_contents((string)$url, false, $ctx);
  if ($res === false) return null;
  $j = json_decode($res, true);
  return $j === null ? $res : $j;
}
// 即时发送：调用本机桥接端点 /api/bot/php-bridge/send-reply，成功返回 true。
// 目标上下文缺失时返回 false（回退累积，脚本结束时由服务端补发），避免回复丢失。
function __php_send_immediate($reply) {
  $base = __php_bridge_url();
  if ($base === '') {
    // 桥接地址缺失：无法即时发送，回退脚本结束统一补发（提示到 stderr 便于服务端日志排查"没回应"）
    if (!defined('__PHP_BRIDGE_WARNED')) { define('__PHP_BRIDGE_WARNED', 1); fwrite(STDERR, "php plugin: bridge url empty, replies will be flushed at script end\n"); }
    return false;
  }
  $t = __php_ctx('TYPE');
  $gid = __php_ctx('GROUP_ID');
  $uid = __php_ctx('USER_ID');
  $cid = __php_ctx('CHANNEL_ID');
  if ($t === 'c2c' && $uid === '') return false;
  if ($t === 'guild' && $cid === '') return false;
  if ($t === 'group' && $gid === '') return false;
  $body = array(
    'bot_id' => __php_bridge_bot_id(),
    'type' => $t,
    'group_id' => $gid,
    'channel_id' => $cid,
    'user_id' => $uid,
    'msg_id' => __php_ctx('MSG_ID'),
    'reply' => $reply,
  );
  $r = curl($base . '/api/bot/php-bridge/send-reply', 'POST', $body, 30);
  if (!is_array($r)) $r = __php_post_json($base . '/api/bot/php-bridge/send-reply', $body, 30);
  return is_array($r) && !empty($r['ok']);
}
}

if (!function_exists('文字')) {
// 文字：发送文本回复（有桥接立即发送，并从累积列表移除避免重复；否则累积到脚本结束输出）
function 文字($content) {
  $idx = count($GLOBALS['__PHP_REPLIES']);
  $GLOBALS['__PHP_REPLIES'][] = array('type' => 'text', 'content' => (string)$content);
  if (__php_send_immediate(array('type' => 'text', 'content' => (string)$content))) {
    unset($GLOBALS['__PHP_REPLIES'][$idx]);
  }
  return true;
}
function send_text($content) { return 文字($content); }

// 图片：发送图片回复（支持 URL / base64 data URI），可附带说明文字（先发文字再发图）
function 图片($url, $caption = '', $fileName = '') {
  $idx = count($GLOBALS['__PHP_REPLIES']);
  if ($caption !== '') $GLOBALS['__PHP_REPLIES'][] = array('type' => 'text', 'content' => (string)$caption);
  $GLOBALS['__PHP_REPLIES'][] = array('type' => 'image', 'imageUrl' => (string)$url, 'fileName' => (string)$fileName);
  $okCap = true;
  $okImg = __php_send_immediate(array('type' => 'image', 'imageUrl' => (string)$url, 'fileName' => (string)$fileName));
  if ($caption !== '') $okCap = __php_send_immediate(array('type' => 'text', 'content' => (string)$caption));
  if ($okCap && $okImg) {
    unset($GLOBALS['__PHP_REPLIES'][$idx]);
    if ($caption !== '') unset($GLOBALS['__PHP_REPLIES'][$idx + 1]);
  } elseif ($okCap) {
    unset($GLOBALS['__PHP_REPLIES'][$idx]);
  } elseif ($okImg) {
    unset($GLOBALS['__PHP_REPLIES'][$idx + 1]);
  }
  return true;
}
function send_image($url, $caption = '', $fileName = '') { return 图片($url, $caption, $fileName); }

// 按钮：发送按钮键盘（rows 二维数组）
function 按钮($rows, $content = ' ') { $GLOBALS['__PHP_REPLIES'][] = 回复按钮($rows, $content); return true; }
// 文卡：发送信息卡片
function 文卡($title, $content, $url = '') { $GLOBALS['__PHP_REPLIES'][] = 回复文卡($title, $content, $url); return true; }
}

// ================= 字符串工具 =================

if (!function_exists('前缀')) {
// 前缀：判断字符串是否以指定前缀开头
function 前缀($str, $prefix) {
  return strpos((string)$str, (string)$prefix) === 0;
}
function str_starts($str, $prefix) { return 前缀($str, $prefix); }
}

// ================= 群信息桥接（调用服务端开放平台，需本机桥接端点） =================
// 底层函数：调用 PHP_PLUGIN_BRIDGE_URL 指向的 /api/bot/php-bridge/* 端点（仅本机可访问）
// 桥接端点由服务端 bot-system 路由提供，PHP 插件在服务器本机运行可直接访问

if (!function_exists('__php_bridge_get')) {
function __php_bridge_url() {
  return defined('PHP_PLUGIN_BRIDGE_URL') ? PHP_PLUGIN_BRIDGE_URL : '';
}
function __php_bridge_bot_id() {
  $b = getenv('PHP_PLUGIN_BOT_ID');
  return $b !== false ? (string)$b : '';
}
function __php_bridge_get($path, $query = array()) {
  $base = __php_bridge_url();
  if ($base === '') return null;
  $q = $query;
  if (!isset($q['bot_id']) && __php_bridge_bot_id() !== '') $q['bot_id'] = __php_bridge_bot_id();
  if ($q) $path .= (strpos($path, '?') === false ? '?' : '&') . http_build_query($q);
  return curl($base . '/api/bot/php-bridge/' . $path);
}
function __php_bridge_post($path, $data) {
  $base = __php_bridge_url();
  if ($base === '') return null;
  return curl($base . '/api/bot/php-bridge/' . $path, 'POST', $data);
}

// 群信息API：官方群信息（群名/群成员数等）。成功返回数组，失败返回 null
function 群信息API($groupOpenid) {
  $r = __php_bridge_get('group-info', array('group_openid' => (string)$groupOpenid));
  return (is_array($r) && !empty($r['ok']) && is_array($r['info'])) ? $r['info'] : null;
}
function group_info_api($groupOpenid) { return 群信息API($groupOpenid); }

// 群成员API：官方群成员列表（分页）。返回 array('members'=>[..], 'next_index'=>..)，失败返回 null
function 群成员API($groupOpenid, $limit = 50, $after = '') {
  $r = __php_bridge_get('group-members', array(
    'group_openid' => (string)$groupOpenid,
    'limit' => (int)$limit,
    'after' => (string)$after,
  ));
  if (!is_array($r) || empty($r['ok'])) return null;
  return array('members' => is_array($r['members']) ? $r['members'] : array(), 'next_index' => (string)($r['next_index'] ?? ''));
}
function group_members_api($groupOpenid, $limit = 50, $after = '') { return 群成员API($groupOpenid, $limit, $after); }

// 群详情API：本地绑定信息（群名/群号）。返回 array('id','name','group_number','avatar') 或 null
function 群详情API($groupOpenid) {
  $r = __php_bridge_get('group-detail', array('group_openid' => (string)$groupOpenid));
  return (is_array($r) && !empty($r['ok']) && is_array($r['group'])) ? $r['group'] : null;
}
function group_detail_api($groupOpenid) { return 群详情API($groupOpenid); }

// 群统计API：与旧版「群信息」看板同源聚合数据。
// 返回 array('groupName','groupId','date','until','metrics'[8项],'topUsers','recentUsers','groupRanking','elapsedMs')
// metrics 元素: array('label','value','color')；topUsers: array('name','masked','count')
// recentUsers: array('name','masked','lastSeen')；groupRanking: array('groupId','name','groupNumber','count')
function 群统计API($groupOpenid) {
  $r = __php_bridge_get('group-stats', array('group_openid' => (string)$groupOpenid));
  return (is_array($r) && !empty($r['ok']) && is_array($r['stats'])) ? $r['stats'] : null;
}
function group_stats_api($groupOpenid) { return 群统计API($groupOpenid); }

// 群排行API：今日各群消息数 TopN（跨所有群）。返回 array(array('groupId','name','groupNumber','count'))
function 群排行API($limit = 5) {
  $r = __php_bridge_get('groups-ranking', array('limit' => (int)$limit));
  return (is_array($r) && !empty($r['ok']) && is_array($r['ranking'])) ? $r['ranking'] : array();
}
function groups_ranking_api($limit = 5) { return 群排行API($limit); }

// 群列表API：机器人所在的所有群（本地记录）。返回数组列表，失败返回 array()
function 群列表API() {
  $r = __php_bridge_get('groups');
  return (is_array($r) && !empty($r['ok']) && is_array($r['groups'])) ? $r['groups'] : array();
}
function groups_api() { return 群列表API(); }

// 绘制群统计卡片：服务端 sharp 渲染竖版长图，返回 base64 data URI；失败返回 ''
// 参数见 GroupStatsCardData：date, groupName, groupDesc, until, metrics[[label,value,color]],
//   topActive[[name,value,score]], topRecent[[name,value,score]], topGroups[[name,value,score]], footer
function 绘制群统计卡片($date, $groupName, $until, $metrics, $topActive, $topRecent, $footer = 'QQ机器人 · 群活跃统计', $topGroups = array(), $groupDesc = '', $elapsedMs = 0) {
  $payload = array(
    'date' => (string)$date,
    'groupName' => (string)$groupName,
    'groupDesc' => (string)$groupDesc,
    'until' => (string)$until,
    'metrics' => array(),
    'topActive' => array(),
    'topRecent' => array(),
    'topGroups' => array(),
    'footer' => (string)$footer,
    'elapsedMs' => (float)$elapsedMs,
  );
  $norm = function ($rows) {
    $out = array();
    foreach ((array)$rows as $r) {
      if (!is_array($r)) continue;
      $name = (string)($r['name'] ?? $r['昵称'] ?? (isset($r[0]) ? $r[0] : ''));
      $value = (string)($r['value'] ?? (isset($r[1]) ? $r[1] : ''));
      $score = (float)($r['score'] ?? (isset($r[2]) ? $r[2] : 0));
      if ($name === '' && $value === '') continue;
      $out[] = array('name' => $name, 'value' => $value, 'score' => $score);
    }
    return $out;
  };
  $payload['metrics'] = array_values(array_filter(array_map(function ($m) {
    if (!is_array($m)) return null;
    $label = (string)($m['label'] ?? (isset($m[0]) ? $m[0] : ''));
    $value = (string)($m['value'] ?? (isset($m[1]) ? $m[1] : ''));
    $color = (string)($m['color'] ?? (isset($m[2]) ? $m[2] : '#3b82f6'));
    if ($label === '') return null;
    return array('label' => $label, 'value' => $value, 'color' => $color);
  }, (array)$metrics)));
  $payload['topActive'] = $norm($topActive);
  $payload['topRecent'] = $norm($topRecent);
  $payload['topGroups'] = $norm($topGroups);
  $r = __php_bridge_post('render-stats-card', $payload);
  if (!is_array($r) || empty($r['ok']) || empty($r['base64'])) return '';
  return 'data:image/png;base64,' . $r['base64'];
}
function draw_group_stats_card($date, $groupName, $until, $metrics, $topActive, $topRecent, $footer = 'QQ机器人 · 群活跃统计', $topGroups = array(), $groupDesc = '', $elapsedMs = 0) {
  return 绘制群统计卡片($date, $groupName, $until, $metrics, $topActive, $topRecent, $footer, $topGroups, $groupDesc, $elapsedMs);
}
} // __php_bridge_get 函数块

// ================= 画布类（基于 GD，用于生成图片） =================

if (function_exists('imagecreatetruecolor') && !class_exists('Canvas')) {
class Canvas {
  private $im; private $w; private $h;
  public function __construct($w = 800, $h = 600, $bg = '#ffffff') {
    $this->w = (int)$w; $this->h = (int)$h;
    $this->im = imagecreatetruecolor($this->w, $this->h);
    imagefill($this->im, 0, 0, $this->_color($bg));
  }
  private function _color($c) {
    $c = ltrim((string)$c, '#');
    if (strlen($c) === 3) $c = $c[0].$c[0].$c[1].$c[1].$c[2].$c[2];
    $r = hexdec(substr($c,0,2)); $g = hexdec(substr($c,2,2)); $b = hexdec(substr($c,4,2));
    return imagecolorallocate($this->im, $r, $g, $b);
  }
  public function width() { return $this->w; }
  public function height() { return $this->h; }
  public function fill($color) { imagefill($this->im, 0, 0, $this->_color($color)); return $this; }
  public function rect($x, $y, $w, $h, $color, $filled = false) {
    if ($filled) imagefilledrectangle($this->im, (int)$x, (int)$y, (int)($x+$w), (int)($y+$h), $this->_color($color));
    else imagerectangle($this->im, (int)$x, (int)$y, (int)($x+$w), (int)($y+$h), $this->_color($color));
    return $this;
  }
  public function line($x1, $y1, $x2, $y2, $color, $thick = 1) {
    imagesetthickness($this->im, (int)$thick);
    imageline($this->im, (int)$x1, (int)$y1, (int)$x2, (int)$y2, $this->_color($color));
    imagesetthickness($this->im, 1);
    return $this;
  }
  public function circle($cx, $cy, $r, $color, $filled = false) {
    if ($filled) imagefilledellipse($this->im, (int)$cx, (int)$cy, (int)($r*2), (int)($r*2), $this->_color($color));
    else imageellipse($this->im, (int)$cx, (int)$cy, (int)($r*2), (int)($r*2), $this->_color($color));
    return $this;
  }
  public function text($x, $y, $text, $size = 20, $color = '#333333') {
    $font = $this->_font();
    if ($font !== '') imagettftext($this->im, (int)$size, 0, (int)$x, (int)($y + $size), $this->_color($color), $font, (string)$text);
    else imagestring($this->im, 5, (int)$x, (int)$y, (string)$text, $this->_color($color));
    return $this;
  }
  public function drawText($x, $y, $text, $size = 20, $color = '#333333') { return $this->text($x, $y, $text, $size, $color); }
  private function _font() {
    $list = array(
      '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
      '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
      '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
      '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
    );
    foreach ($list as $f) if (is_file($f)) return $f;
    return '';
  }
  // 保存为 PNG 到 data/database，返回文件绝对路径；name 不含扩展名时自动补 .png
  public function save($name) {
    $name = str_replace(array('..', '/', '\\', "\0"), '', (string)$name);
    if ($name === '') return '';
    $f = __php_data_dir() . '/' . $name;
    if (strpos(basename($f), '.') === false) $f .= '.png';
    @imagepng($this->im, $f);
    imagedestroy($this->im);
    return $f;
  }
  // 返回 base64 data URI（可直接作为回复图片内容）
  public function base64() {
    ob_start();
    imagepng($this->im);
    $b = base64_encode(ob_get_clean());
    imagedestroy($this->im);
    return 'data:image/png;base64,' . $b;
  }
}
}

} // PHP_HELPERS_LOADED

// ================= 更新系统辅助（更新插件使用） =================
// 以下函数独立于 PHP_HELPERS_LOADED 之外，始终可用

if (!function_exists('更新配置')) {
// 更新配置：版本/补丁URL/全量URL/更新内容。
// 数据来源（多源自动回退）：
//   1) 面板桥接配置（本机 db：update.* + update.config_url）
//   2) 云端 update-config.json（唯一源：AI 服务器 8091，用户指定；GitHub 不再作机器人更新源，代码仓库仍照常同步）
//      云端优先，拉取失败回退本机配置。
// 返回额外带 patchUrls/fullUrls（主源 + 全部镜像，去重），供下载时主源失败自动切换。
function 更新配置() {
  $bridge = __php_bridge_get('update-config');
  $local = array(
    'version' => (string)($bridge['version'] ?? ''),
    'patchUrl' => (string)($bridge['patchUrl'] ?? ''),
    'fullUrl' => (string)($bridge['fullUrl'] ?? ''),
    'changeLog' => (string)($bridge['changeLog'] ?? ''),
    'configUrl' => trim((string)($bridge['configUrl'] ?? '')),
    'botName' => trim((string)($bridge['botName'] ?? '')),
  );
  $cfg = $local;
  $cfg['sourceUrl'] = '';
  $cfg['patchUrls'] = array();
  $cfg['fullUrls'] = array();

  $urls = array();
  if ($cfg['configUrl'] !== '') {
    foreach (preg_split('/[\s,]+/', $cfg['configUrl']) as $u) { $u = trim($u); if ($u !== '') $urls[] = $u; }
  }
  foreach (array(
    // 8091 主源优先（快且稳），其后为 GitHub / 镜像兜底，任一可达即用，全部失败再回退本机面板配置
    'https://8091-6f61dc7363389b7a.monkeycode-ai.online/update-config.json',
    'https://raw.githubusercontent.com/lzyzyzq/QQgfbot/main/update-config.json',
    'https://lzyzyzq.github.io/QQgfbot/update-config.json',
    'https://raw.gitmirror.com/lzyzyzq/QQgfbot/main/update-config.json',
  ) as $u) $urls[] = $u;

  foreach (array_unique($urls) as $u) {
    $txt = 抓取文本($u);
    if ($txt === '') continue;
    $j = json_decode($txt, true);
    if (!is_array($j) || empty($j['ok'])) continue;
    $v = trim((string)($j['version'] ?? ''));
    $p = trim((string)($j['patchUrl'] ?? ''));
    $f = trim((string)($j['fullUrl'] ?? ''));
    if ($v === '' && $p === '' && $f === '') continue;
    if ($v !== '') $cfg['version'] = $v;
    if ($p !== '') $cfg['patchUrl'] = $p;
    if ($f !== '') $cfg['fullUrl'] = $f;
    if (trim((string)($j['changeLog'] ?? '')) !== '') $cfg['changeLog'] = trim((string)$j['changeLog']);
    $cfg['sourceUrl'] = $u;
    $mir = is_array($j['mirrors'] ?? null) ? $j['mirrors'] : array();
    $add = function (&$arr, $v) { $v = trim((string)$v); if ($v !== '' && !in_array($v, $arr, true)) $arr[] = $v; };
    $add($cfg['patchUrls'], $cfg['patchUrl']);
    $add($cfg['fullUrls'], $cfg['fullUrl']);
    foreach ($mir as $m) {
      if (!is_array($m)) continue;
      $add($cfg['patchUrls'], $m['patchUrl'] ?? '');
      $add($cfg['fullUrls'], $m['fullUrl'] ?? '');
    }
    // 兜底本机配置地址也纳入候选
    $add($cfg['patchUrls'], $local['patchUrl']);
    $add($cfg['fullUrls'], $local['fullUrl']);
    break;
  }
  if (count($cfg['patchUrls']) === 0) {
    $cfg['patchUrls'] = $cfg['patchUrl'] !== '' ? array($cfg['patchUrl']) : array();
    $cfg['fullUrls'] = $cfg['fullUrl'] !== '' ? array($cfg['fullUrl']) : array();
  }
  return $cfg;
}
function update_config() { return 更新配置(); }

// 抓取远程文本（返回 '' 表示失败）；curl 超时 10s，跟随重定向，忽略 SSL 证书校验
// 服务器未装 php-curl 扩展时用 file_get_contents 回退
function 抓取文本($url) {
  if ((string)$url === '') return '';
  if (!function_exists('curl_init')) {
    if (!(bool)ini_get('allow_url_fopen')) return '';
    $ctx = stream_context_create(array(
      'http' => array('timeout' => 10, 'follow_location' => 1, 'user_agent' => 'qq-bot-php-plugin-updater'),
      'ssl' => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    $body = @file_get_contents((string)$url, false, $ctx);
    return $body === false ? '' : (string)$body;
  }
  $ch = curl_init((string)$url);
  curl_setopt_array($ch, array(
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'qq-bot-php-plugin-updater',
  ));
  $body = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($body === false || $code >= 400) return '';
  return (string)$body;
}

// 是否超级主人：openid 属于 admin.json 超主，或超主 QQ 名下的任一 OpenID
function 是否超主($openid) {
  if ((string)$openid === '') return false;
  $r = __php_bridge_post('is-master', array('openid' => (string)$openid));
  return is_array($r) && !empty($r['ok']) && !empty($r['master']);
}
function is_master($openid) { return 是否超主($openid); }

// 群内授权查询：后台标注 role（group_members.role）+ 实时群主对照。
// 返回 array('role','role_ok','realtime_owner','allowed')，查询失败返回 null。
function 群内授权($groupOpenid, $memberOpenid) {
  if ((string)$groupOpenid === '' || (string)$memberOpenid === '') return null;
  $r = __php_bridge_get('group-member-auth', array(
    'group_openid' => (string)$groupOpenid,
    'member_openid' => (string)$memberOpenid,
    'bot_id' => __php_bridge_bot_id(),
  ));
  return (is_array($r) && !empty($r['ok'])) ? $r : null;
}
function group_auth($g, $m) { return 群内授权($g, $m); }

// 是否群管理（群主/群管理，后台标注 owner/admin/super 或实时群主）
function 是否群管理($groupOpenid, $memberOpenid) {
  $a = 群内授权($groupOpenid, $memberOpenid);
  if ($a === null) return false;
  return !empty($a['allowed']);
}
function is_group_admin($g, $m) { return 是否群管理($g, $m); }

// 终端命令授权：超级主人 或 群主/群管理
function 终端授权($groupOpenid, $memberOpenid) {
  if (是否超主($memberOpenid)) return true;
  return 是否群管理($groupOpenid, $memberOpenid);
}
function terminal_allowed($g, $m) { return 终端授权($g, $m); }

// 执行终端命令：把整条命令交给 bash 执行（2>&1 合并输出），成功返回 array('code','lines')。
// 安全说明：仅调用方已通过 终端授权() 校验时才允许执行；本函数不做白名单过滤（任意命令能力）。
function 执行终端命令($cmd, $timeout = 55) {
  if (!function_exists('exec')) return array('code' => -1, 'lines' => array('❌ 服务器未启用 PHP exec，无法执行终端命令。'));
  $timeout = max(3, min(90, (int)$timeout));
  $lines = array();
  $code = 0;
  $pre = "cd " . escapeshellarg(更新根目录()) . " 2>/dev/null; ";
  @exec('timeout ' . $timeout . ' bash -c ' . escapeshellarg($pre . (string)$cmd) . ' 2>&1', $lines, $code);
  return array('code' => (int)$code, 'lines' => $lines);
}
function exec_terminal($cmd, $timeout = 55) { return 执行终端命令($cmd, $timeout); }

// 终端输出截断：完整输出优先；超长时截取 重点错误行 + 末尾 keepTail 行。
// $maxChars 单条消息字符预算（含 at 与标题时外部自行留余）。
// 返回 array('text','truncated')
function 截断终端输出($lines, $maxChars = 3800, $keepTail = 30) {
  $all = array();
  foreach ((array)$lines as $l) $all[] = rtrim((string)$l, "\r");
  while (count($all) > 0 && end($all) === '') array_pop($all);
  $text = implode("\n", $all);
  if ($text === '') return array('text' => '✅ 命令执行完成（无输出）', 'truncated' => false);
  if (mb_strlen($text, 'UTF-8') <= $maxChars) return array('text' => $text, 'truncated' => false);
  // 优先收集错误/警告行（含 error/❌/fail/denied/refused/Exception/错误/失败/找不到/无法）
  $err = array();
  foreach ($all as $l) {
    if (preg_match('/error|❌|fail(ed)?|denied|refused|exception|错误|失败|找不到|无法|没有那个|No such|cannot|warning/i', $l)) $err[] = $l;
  }
  $head = array();
  $budget = $maxChars;
  $grab = function ($src, &$dst) use (&$budget) {
    foreach ($src as $l) {
      $add = mb_strlen($l, 'UTF-8') + 1;
      if ($budget - $add < 40) break;
      $dst[] = $l; $budget -= $add;
    }
  };
  $head[] = '⚠️ 输出过长（' . count($all) . ' 行），已截取：';
  $budget -= mb_strlen($head[0], 'UTF-8');
  if (count($err) > 0) $grab($err, $head);
  if ($budget > 200) {
    $head[] = '…';
    $budget -= 2;
    $grab(array_slice($all, -1 * (int)$keepTail), $head);
  }
  return array('text' => implode("\n", $head), 'truncated' => true);
}
function truncate_terminal($lines, $maxChars = 3800, $keepTail = 30) { return 截断终端输出($lines, $maxChars, $keepTail); }

// 下载文件：二进制下载到本地路径，成功返回 true。
// $timeout 单次下载超时秒数（默认 30，避免长任务拖垮 PHP 插件进程预算 120s 导致"没回应"）。
// $errRef 可传入变量名：下载失败时回填原因（curl 错误/HTTP 状态码/文件大小）
function 下载文件($url, $dst, $timeout = 30, &$errRef = null) {
  $errRef = '';
  if ((string)$url === '') { $errRef = '下载地址为空'; return false; }
  if (!function_exists('curl_init')) {
    // 无 curl 扩展：copy() 流式下载回退（需开启 allow_url_fopen）
    if (!(bool)ini_get('allow_url_fopen')) { $errRef = '当前环境无 curl 扩展且已禁用 allow_url_fopen'; return false; }
    $ctx = stream_context_create(array(
      'http' => array('timeout' => max(5, min(60, (int)$timeout)), 'follow_location' => 1, 'user_agent' => 'qq-bot-php-plugin-updater'),
      'ssl' => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    $ok = @copy((string)$url, (string)$dst, $ctx);
    if ($ok === false || @filesize((string)$dst) <= 0) { $errRef = '网络错误或文件为空'; @unlink((string)$dst); return false; }
    return true;
  }
  $fp = @fopen((string)$dst, 'wb');
  if (!$fp) { $errRef = '无法写入本地文件目录'; return false; }
  $ch = curl_init((string)$url);
  curl_setopt_array($ch, array(
    CURLOPT_FILE => $fp,
    CURLOPT_TIMEOUT => max(5, min(60, (int)$timeout)),
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_USERAGENT => 'qq-bot-php-plugin-updater',
  ));
  $ok = curl_exec($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $cerr = curl_error($ch);
  curl_close($ch);
  fclose($fp);
  if ($ok === false || $code >= 400 || @filesize((string)$dst) <= 0) {
    $errRef = $ok === false ? '网络错误：' . (string)$cerr : 'HTTP ' . $code;
    @unlink((string)$dst);
    return false;
  }
  return true;
}
function download_file($url, $dst, $timeout = 30, &$errRef = null) { return 下载文件($url, $dst, $timeout, $errRef); }

// 版本号比较：a>b 返回 1，a==b 返回 0，a<b 返回 -1（按数字分段比较，忽略非数字字符）
function 版本比较($a, $b) {
  $pa = explode('.', preg_replace('/[^0-9.]/', '', (string)$a));
  $pb = explode('.', preg_replace('/[^0-9.]/', '', (string)$b));
  $n = max(count($pa), count($pb));
  for ($i = 0; $i < $n; $i++) {
    $x = (int)($pa[$i] ?? 0); $y = (int)($pb[$i] ?? 0);
    if ($x > $y) return 1;
    if ($x < $y) return -1;
  }
  return 0;
}
function compare_versions($a, $b) { return 版本比较($a, $b); }

// 更新系统根目录：服务器代码根（unzip 解压目标）。可用环境变量 PHP_PLUGIN_ROOT_DIR 覆盖
function 更新根目录() {
  $env = getenv('PHP_PLUGIN_ROOT_DIR');
  if ($env !== false && $env !== '') return rtrim((string)$env, '/');
  $cwd = getcwd();
  if (is_dir($cwd . '/plugins')) return $cwd;
  if (is_dir(dirname($cwd) . '/plugins')) return dirname($cwd);
  return $cwd;
}
function update_root() { return 更新根目录(); }

// 延迟重启 qqbot（pm2）：先输出回复，sleep 后才重启，保证回复已发出
function 延迟重启机器人($秒 = 3) {
  if (!function_exists('exec')) return false;
  $root = 更新根目录();
  // 记录重启时间戳：重启完成后「重启控制」插件据此广播「重启完成 · 用时 X 秒」
  @file_put_contents($root . '/.reboot-ts', (string)round(microtime(true) * 1000));
  $cmd = "nohup bash -c 'sleep " . (int)$秒 . "; cd " . escapeshellarg($root) . " && pm2 restart qqbot' >/dev/null 2>&1 &";
  @exec($cmd);
  return true;
}
function restart_bot_delayed($秒 = 3) { return 延迟重启机器人($秒); }

// 更新数据目录（data/database/更新）
function 更新数据目录() {
  $dir = __php_data_dir() . '/更新';
  if (!is_dir($dir)) @mkdir($dir, 0777, true);
  return $dir;
}

// 更新记录：操作 '读取' 返回列表数组；'追加' 追加条目；'删除' 按序号删除，返回 true/false
function 更新记录($操作 = '读取', $条目 = null, $序号 = -1) {
  $dir = 更新数据目录();
  $f = $dir . '/记录.json';
  $list = array();
  if (is_file($f)) { $j = json_decode(@file_get_contents($f), true); if (is_array($j)) $list = $j; }
  if ((string)$操作 === '追加' && is_array($条目)) {
    $list[] = $条目;
    @file_put_contents($f, json_encode($list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
    return true;
  }
  if ((string)$操作 === '删除') {
    $idx = (int)$序号;
    if ($idx >= 0 && $idx < count($list)) {
      array_splice($list, $idx, 1);
      @file_put_contents($f, json_encode($list, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
      return true;
    }
    return false;
  }
  return $list;
}
function update_records($op = '读取', $item = null, $idx = -1) { return 更新记录($op, $item, $idx); }

// 当前部署版本（data/database/更新/状态.json 记录），空表示从未记录
function 当前版本() {
  $f = 更新数据目录() . '/状态.json';
  if (!is_file($f)) return '';
  $j = json_decode(@file_get_contents($f), true);
  return is_array($j) ? (string)($j['version'] ?? '') : '';
}
function current_version() { return 当前版本(); }

// 记录当前部署版本
function 记录当前版本($version) {
  $f = 更新数据目录() . '/状态.json';
  @file_put_contents($f, json_encode(array('version' => (string)$version, 'updatedAt' => 当前时间()), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}
function record_current_version($version) { return 记录当前版本($version); }

// 更新菜单图片：服务端 sharp 渲染，返回 base64 data URI；失败返回 ''
function 更新菜单图片($data) {
  $r = __php_bridge_post('render-update-card', array('data' => (array)$data));
  if (!is_array($r) || empty($r['ok']) || empty($r['base64'])) return '';
  return 'data:image/png;base64,' . $r['base64'];
}
function render_update_card($data) { return 更新菜单图片($data); }

// 文字外显链接：[显示文字](mqqapi://aio/inlinecmd?command=指令&enter=false&reply=false)
function 外显($label, $cmd) {
  return '[' . (string)$label . '](mqqapi://aio/%69nlinecmd?command=' . urlencode((string)$cmd) . '&enter=false&reply=false)';
}
function inline_link($label, $cmd) { return 外显($label, $cmd); }

// Markdown 快捷回复（文字外显链接需 markdown 才可点击）
// 与 文字/图片 一致：有桥接立即发送并移出累积，避免长任务（更新/下载）超时导致按钮丢失
function Markdown($content) {
  $idx = count($GLOBALS['__PHP_REPLIES']);
  $GLOBALS['__PHP_REPLIES'][] = array('type' => 'markdown', 'content' => (string)$content);
  if (__php_send_immediate(array('type' => 'markdown', 'content' => (string)$content))) {
    unset($GLOBALS['__PHP_REPLIES'][$idx]);
  }
  return true;
}
function send_markdown($content) { return Markdown($content); }
} // 更新系统辅助

// ============================================================
// 更新系统插件：群内发「更新」调出更新菜单，自动下载/解压/重启升级
// ------------------------------------------------------------
// 命令：
//   更新 / 更新菜单 / 返回更新  → 图片菜单 + 文字外显按钮
//   更新补丁 / 更新补丁包        → 下载补丁包并升级
//   更新全量 / 更新全量包        → 下载全量包并升级
//   检查更新                   → 版本对比，有更新提醒
//   更新记录 / 更新列表          → 历史更新列表
//   删除更新记录 [序号]          → 删除指定更新记录
//   返回菜单                   → 回主菜单（文字外显）
// ------------------------------------------------------------
// 权限：超级主人 / 群主 / 群管理员（后台成员管理标注 role）可使用。
// 更新包配置（版本号/补丁地址/全量地址/更新内容）在管理面板
// 「系统设置 → 更新系统配置」中维护；默认版本 4.2.59。
// 版本判断依据：更新包版本 与 本机已部署版本（data/database/更新/状态.json）
// 对比，更新包版本高于本机版本才提示/允许更新。
// ============================================================

$in = json_decode(stream_get_contents(STDIN), true);
if (!$in || !is_array($in)) { fwrite(STDERR, "无效输入\n"); exit(0); }

$类型 = (string)($in['type'] ?? '');
$消息 = trim((string)($in['content'] ?? ''));

// 剥离消息开头对机器人的 @ 提及（QQ 按钮 inlinecmd / AT 产生的 "<@!openid> 更新补丁"），只保留命令本体，
// 否则前缀匹配「更新补丁」会失败导致发了没回应。
while (true) {
  $去 = preg_replace('/^<@!?[0-9A-Fa-f]+>\s*/', '', $消息);
  $去 = preg_replace('/^@\S+\s*/', '', $去);
  if ($去 === $消息) break;
  $消息 = trim($去);
}

$群 = (string)($in['groupId'] ?? '');
$用户 = (string)($in['userId'] ?? '');

if ($类型 !== 'group') exit(0); // 仅群聊
if ($群 === '') exit(0);

$at = "<@!" . $用户 . ">";

// 「终端 / 执行」前缀统一交给「终端.php」插件执行任意命令（本插件不再抢答，
// 即使后续内容是 cd/wget/unzip 等升级命令形态，也由终端插件原样 shell 执行）。
if (preg_match('/^(?:终端|执行)(?:\s|$)/u', $消息)) exit(0);

// ========== 终端命令直接更新（与面板部署终端串联） ==========
// 群里直接发送（仅超主/群主/群管理，URL 为补丁/全量包下载地址）：
//   cd /var/www/php && wget -O patch-4.2.64.zip <补丁URL> && unzip -o patch-4.2.64.zip && pm2 restart qqbot
// 兼容增强：
//   - 多条 wget/unzip 链以 && 连续（例如先升补丁再升下一补丁，最后统一重启）
//   - 命令中可含 # 注释行与换行（QQ 复制多行命令也识别）
//   - 兼容 QQ 在命令间插入的空格/零宽字符
// 识别成功后逐包执行：下载 → unzip -t 校验 → unzip -o 解压，每步群内反馈，全部完成才 pm2 restart qqbot。
$终端更新 = 解析终端更新命令($消息);
if ($终端更新 !== null) {
  if (!终端授权($群, $用户)) {
    文字($at . "\n「终端更新」仅 超级主人 / 群主 / 群管理员 可使用。如需升级请联系管理员。");
    exit(0);
  }
  $root = 更新根目录();
  $steps = $终端更新['steps'];
  $total = count($steps);
  $cfgU = 更新配置();
  $doneVer = '';
  foreach ($steps as $i => $st) {
    $n = $i + 1;
    $zip = $st['zip']; $url = $st['url']; $kind = $st['kind'];
    文字($at . "\n⏳ (" . $n . "/" . $total . ") 正在下载" . $kind . " " . $zip . " …");
    $zipPath = 更新数据目录() . '/' . $zip;
    // 候选源：优先用户给的地址，再依次回退云端镜像；单源超时 25s，累计不超过 2 个候选，防止拖垮 120s 预算
    $cands = array_unique(array_merge(array($url), $kind === '补丁包' ? $cfgU['patchUrls'] : $cfgU['fullUrls']));
    $dlErr = '';
    $dlOK = false;
    $tried = 0;
    foreach ($cands as $cu) {
      $tried++;
      if (下载文件($cu, $zipPath, 25, $dlErr)) { $dlOK = true; break; }
      if ($tried >= 2) break;
    }
    if (!$dlOK) {
      文字($at . "\n❌ (" . $n . "/" . $total . ") 下载失败：" . $zip . ($dlErr !== '' ? "（" . $dlErr . "）" : '') . "\n请检查下载地址可访问后重新发送。");
      exit(0);
    }
    if (!function_exists('exec')) {
      文字($at . "\n❌ 服务器未启用 PHP exec，无法自动解压/重启。\n请手动执行：\ncd " . $root . " && unzip -o " . $zipPath . " && pm2 restart qqbot");
      @unlink($zipPath);
      exit(0);
    }
    exec('cd ' . escapeshellarg($root) . ' && unzip -t ' . escapeshellarg($zipPath) . ' 2>&1', $tOut, $tCode);
    if ($tCode !== 0) {
      文字($at . "\n❌ (" . $n . "/" . $total . ") 压缩包校验失败：" . $zip . "（服务器未安装 unzip 或文件损坏）。");
      @unlink($zipPath);
      exit(0);
    }
    exec('cd ' . escapeshellarg($root) . ' && unzip -o ' . escapeshellarg($zipPath) . ' 2>&1', $uOut, $uCode);
    if ($uCode !== 0) {
      文字($at . "\n❌ (" . $n . "/" . $total . ") 解压失败：" . $zip . "\n" . implode("\n", array_slice($uOut, 0, 4)));
      @unlink($zipPath);
      exit(0);
    }
    @unlink($zipPath);
    if (preg_match('/(\d+(?:\.\d+){1,3})/', $zip, $vm)) $doneVer = $vm[1];
    更新记录('追加', array('type' => $kind, 'version' => $doneVer, 'time' => 当前时间(), 'content' => '群内终端命令更新：' . $zip));
    文字($at . "\n✅ (" . $n . "/" . $total . ") " . $kind . " " . $zip . " 已解压完成" . ($total > 1 ? "（" . $n . "/" . $total . "）" : ''));
  }
  if ($doneVer !== '') 记录当前版本($doneVer);
  $verTxt = '';
  $vers = array();
  foreach ($steps as $st) { if (preg_match('/(\d+(?:\.\d+){1,3})/', $st['zip'], $vm)) $vers[] = $vm[1]; }
  $vers = array_values(array_unique($vers));
  if (count($vers) > 0) $verTxt = "（" . implode(' → ', $vers) . "）";
  文字($at . "\n🎉 更新完成！" . $total . " 个更新包已全部解压" . $verTxt . "，3 秒后自动重启机器人…\n重启后本群会收到新版本状态广播，即为升级成功。");
  Markdown("　" . 外显('返回更新', '返回更新') . '　' . 外显('返回菜单', '菜单'));
  延迟重启机器人(3);
  exit(0);
}

// 终端更新识别失败：消息长得像终端命令但解析不通过时，给有权限者明确原因，避免"发了没回应"
if ($终端更新 === null && 终端授权($群, $用户) && 形似终端更新命令($消息)) {
  文字($at . "\n⚠️ 未识别到可执行的终端更新命令。\n请核对后重发：\n1) 目录需为 " . 更新根目录() . "\n2) 需含 wget -O 包名.zip 下载地址（http/https）\n3) 需含 unzip 与 pm2 restart qqbot\n支持 # 注释、换行与多个更新包连续升级。\n也可直接发送「更新补丁」或「更新全量」使用内置按钮更新。");
  exit(0);
}

// ========== 命令命中判断 ==========
$命令命中 = false;
if ($消息 === '更新' || $消息 === '更新菜单' || $消息 === '返回更新') $命令命中 = true;
elseif (前缀($消息, '更新补丁') || 前缀($消息, '更新全量')) $命令命中 = true;
elseif ($消息 === '检查更新' || 前缀($消息, '检查更新')) $命令命中 = true;
elseif (前缀($消息, '更新记录') || 前缀($消息, '更新列表')) $命令命中 = true;
elseif (前缀($消息, '删除更新记录')) $命令命中 = true;
if (!$命令命中) exit(0);

// ========== 权限：超主 / 群主 / 群管理（菜单与按钮命令） ==========
if (!终端授权($群, $用户)) {
  文字($at . "\n「更新系统」仅 超级主人 / 群主 / 群管理员 可使用。如需升级请联系管理员。");
  exit(0);
}

// ========== 更新配置与版本对比 ==========
$cfg = 更新配置();
// 机器人标识：多机器人同群时，提醒中标明是哪个机器人发的（取自桥接 update-config）
$机器人 = trim((string)($cfg['botName'] ?? ''));
$前缀 = $机器人 !== '' ? ('[' . $机器人 . '] ') : '';
$版本 = $cfg['version'] !== '' ? $cfg['version'] : '4.2.59';
$当前 = 当前版本();
if ($当前 === '') { $当前 = $版本; 记录当前版本($版本); } // 首次以更新包版本为基线
$hasUpdate = 版本比较($版本, $当前) === 1;
// 远程更新源（update-config.json）是否拉取成功：失败时不得误报「已是最新版本」
$remoteOk = trim((string)($cfg['sourceUrl'] ?? '')) !== '';

$更新内容默认 = "更新系统界面全新美化：版本信息卡/更新状态徽章/更新历史\n检查更新无论有无新版本都会提醒\n群号「截至时间」显示用户发送命令的时刻（北京时间）\n更新到服务器后执行：cd /var/www/php && pm2 restart qqbot";
$changelog = $cfg['changeLog'] !== '' ? $cfg['changeLog'] : $更新内容默认;

// ========== 辅助 ==========
function 更新按钮行() {
  return 外显('更新补丁', '更新补丁') . '　' . 外显('更新全量', '更新全量') . '　' . 外显('检查更新', '检查更新') . "\n" .
         外显('更新记录', '更新记录') . '　' . 外显('返回更新', '返回更新') . '　' . 外显('返回菜单', '菜单');
}

function 发送更新菜单($版本, $当前, $cfg, $changelog, $hasUpdate, $at, $caption = '', $remoteOk = true, $前缀 = '') {
  if ($caption === '') $caption = $at . "\n" . $前缀 . "「更新系统」";
  文字($caption);
  $records = 更新记录('读取');
  $lastUpdate = '';
  if (count($records) > 0) { $lastUpdate = (string)end($records)['time']; }
  $img = 更新菜单图片(array(
    'version' => $版本,
    'current' => $当前,
    'patchUrl' => $cfg['patchUrl'],
    'fullUrl' => $cfg['fullUrl'],
    'changeLog' => $changelog,
    'hasUpdate' => $hasUpdate,
    'remoteOk' => (bool)$remoteOk,
    'checkedAt' => 当前时间(),
    'lastUpdate' => $lastUpdate,
    'recordCount' => count($records),
  ));
  if ($img !== '') {
    图片($img, '', '更新系统.png');
  } else {
    $状态行 = $hasUpdate ? ("⚠️ 发现新版本 v" . $版本) : ($remoteOk ? ("✅ 已是最新版本 v" . $当前) : "⚠️ 未能确认最新版本（更新源不可达）");
    文字($前缀 . "当前版本：" . $当前 . "\n更新包版本：" . $版本 . "\n" . $状态行 . "\n\n【更新内容】\n" . $changelog);
  }
  Markdown("　" . 更新按钮行());
}

// ========== 命令分发 ==========

// 更新菜单
if ($消息 === '更新' || $消息 === '更新菜单' || $消息 === '返回更新') {
  发送更新菜单($版本, $当前, $cfg, $changelog, $hasUpdate, $at, '', $remoteOk, $前缀);
  exit(0);
}

// 执行更新（补丁/全量）
if (前缀($消息, '更新补丁') || 前缀($消息, '更新全量')) {
  $isPatch = 前缀($消息, '更新补丁');
  $urls = $isPatch ? $cfg['patchUrls'] : $cfg['fullUrls'];
  $kind = $isPatch ? '补丁包' : '全量包';

  if (count($urls) === 0) {
    文字($at . "\n" . $前缀 . "未配置" . $kind . "下载地址。请在管理面板「系统设置 → 更新系统配置」中填写更新包地址。");
    exit(0);
  }
  if (!$hasUpdate && $当前 !== '') {
    文字($at . "\n" . $前缀 . "当前版本（" . $当前 . "）已不低于更新包版本（" . $版本 . "），无需升级。");
    exit(0);
  }
  if ($当前 !== '' && 版本比较($版本, $当前) === 0) {
    文字($at . "\n" . $前缀 . "当前已是最新版本（" . $版本 . "），无需重复更新。");
    exit(0);
  }

  文字($at . "\n" . $前缀 . "⏳ 正在下载" . $kind . " v" . $版本 . "（" . count($urls) . " 个候选源，主源失败自动切换）…");

  $zip = 更新数据目录() . '/update-' . ($isPatch ? 'patch' : 'full') . '.zip';
  $dlUrl = '';
  $dlErr = '';
  foreach ($urls as $u) {
    if (下载文件($u, $zip, 30, $dlErr)) { $dlUrl = $u; break; }
  }
  if ($dlUrl === '') {
    文字($at . "\n" . $前缀 . "❌ 下载失败（候选源均不可用" . ($dlErr !== '' ? '：' . $dlErr : '') . "）：\n" . implode("\n", $urls));
    exit(0);
  }
  $root = 更新根目录();
  if (!function_exists('exec')) {
    文字($at . "\n" . $前缀 . "❌ 服务器未启用 PHP exec，无法自动解压/重启。\n请手动执行：\ncd " . $root . " && unzip -o " . $zip . " && pm2 restart qqbot");
    exit(0);
  }
  // 校验
  exec('cd ' . escapeshellarg($root) . ' && unzip -t ' . escapeshellarg($zip) . ' 2>&1', $tOut, $tCode);
  if ($tCode !== 0) {
    文字($at . "\n" . $前缀 . "❌ 压缩包校验失败（服务器未安装 unzip 或文件损坏）。");
    exit(0);
  }
  // 解压
  exec('cd ' . escapeshellarg($root) . ' && unzip -o ' . escapeshellarg($zip) . ' 2>&1', $uOut, $uCode);
  if ($uCode !== 0) {
    文字($at . "\n" . $前缀 . "❌ 解压失败：\n" . implode("\n", array_slice($uOut, 0, 5)));
    exit(0);
  }
  @unlink($zip);

  记录当前版本($版本);
  更新记录('追加', array('type' => $kind, 'version' => $版本, 'time' => 当前时间(), 'content' => $changelog));

  文字($at . "\n" . $前缀 . "✅ 更新完成！已升级到 v" . $版本 . "（" . $kind . "）。\n\n【本轮更新内容】\n" . $changelog . "\n\n3 秒后自动重启机器人…");
  Markdown("　" . 外显('返回更新', '返回更新') . '　' . 外显('返回菜单', '菜单'));
  延迟重启机器人(3);
  exit(0);
}

// 检查更新：无论有无新版本都明确提醒（附带状态菜单图片）
if ($消息 === '检查更新' || 前缀($消息, '检查更新')) {
  if ($hasUpdate) {
    发送更新菜单($版本, $当前, $cfg, $changelog, $hasUpdate, $at,
      $at . "\n" . $前缀 . "⚠️ 发现新版本 v" . $版本 . "（当前 v" . $当前 . "），更新内容见下图，可发送「更新补丁」或「更新全量」升级。",
      $remoteOk, $前缀);
  } elseif (!$remoteOk) {
    发送更新菜单($版本, $当前, $cfg, $changelog, $hasUpdate, $at,
      $at . "\n" . $前缀 . "⚠️ 未能确认最新版本：更新源（update-config.json）不可达。当前部署 v" . $当前 . "。\n请稍后重试，或检查管理面板「系统设置 → 更新系统配置」的网络与地址。",
      $remoteOk, $前缀);
  } else {
    发送更新菜单($版本, $当前, $cfg, $changelog, $hasUpdate, $at,
      $at . "\n" . $前缀 . "✅ 已检查更新：当前版本 v" . $当前 . " 已是最新，无需升级。",
      $remoteOk, $前缀);
  }
  exit(0);
}

// 更新记录（读取列表）
if (前缀($消息, '更新记录') || 前缀($消息, '更新列表')) {
  $list = 更新记录('读取');
  if (count($list) === 0) { 文字($at . "\n" . $前缀 . "暂无更新记录。"); exit(0); }
  $rows = array();
  foreach ($list as $i => $it) {
    $rows[] = ($i + 1) . ". [" . ($it['time'] ?? '') . "] " . ($it['type'] ?? '') . " v" . ($it['version'] ?? '') . "\n   " . mb_substr(str_replace("\n", ' ', $it['content'] ?? ''), 0, 40);
  }
  文字($at . "\n" . $前缀 . "📋 更新记录（共 " . count($list) . " 条）：\n" . implode("\n", $rows) . "\n\n发送「删除更新记录 序号」可删除对应记录。");
  Markdown("　" . 外显('删除更新记录', '删除更新记录') . '　' . 外显('返回更新', '返回更新'));
  exit(0);
}

// 删除更新记录
if (前缀($消息, '删除更新记录')) {
  $parts = preg_split('/\s+/', trim($消息));
  $序号 = isset($parts[1]) && is_numeric($parts[1]) ? ((int)$parts[1] - 1) : -1;
  if ($序号 < 0) {
    $list = 更新记录('读取');
    if (count($list) === 0) { 文字($at . "\n暂无更新记录。"); exit(0); }
    $lines = array();
    foreach ($list as $i => $it) $lines[] = ($i + 1) . ". " . ($it['time'] ?? '') . " " . ($it['type'] ?? '') . " v" . ($it['version'] ?? '');
    文字($at . "\n请指定要删除的序号（如「删除更新记录 1」）：\n" . implode("\n", $lines));
    exit(0);
  }
  if (更新记录('删除', null, $序号)) 文字($at . "\n✅ 已删除更新记录第 " . ($序号 + 1) . " 条。");
  else 文字($at . "\n❌ 序号无效（共 " . count(更新记录('读取')) . " 条记录）。");
  exit(0);
}

// ========== 终端更新命令解析 ==========
// 识别群内直接发送的更新命令（兼容多包连续 + # 注释/换行 + 零宽字符）：
//   cd <更新根目录> && wget -O <zip> <url> && unzip -o <zip> [&& ... ] && pm2 restart qqbot
// 只做白名单提取（目录/zip 名/URL/进程名逐一校验），从不直接执行消息原文，防止命令注入。
// 无法识别返回 null 走「形似终端更新命令」提示分支。

// 归一化：去掉 # 注释行与空行、零宽字符（QQ 分词可能插入），多空格/换行折叠为单个空格
function 归一化终端文本($msg) {
  $msg = (string)$msg;
  $msg = preg_replace('/[\x{200b}\x{200c}\x{200d}\x{feff}\x{2060}]/u', '', $msg); // 零宽字符直接删除
  $msg = preg_replace('/\x{a0}/u', ' ', $msg);                                       // 不间断空格 → 空格
  $out = array();
  foreach (preg_split('/\r?\n/u', $msg) as $l) {
    $t = trim($l);
    if ($t === '') continue;
    if (preg_match('/^\s*#/', $t)) continue;      // 注释行
    if (preg_match('#^\s*//#', $t)) continue;     // 注释行
    $out[] = $t;
  }
  return preg_replace('/\s+/u', ' ', implode(' ', $out));
}

function 解析终端更新命令($msg) {
  $msg = 归一化终端文本($msg);
  if ($msg === '') return null;
  $root = 更新根目录();
  if (!preg_match('/^cd\s+(\S+)/iu', $msg, $m)) return null;
  if (rtrim($m[1], '/') !== rtrim($root, '/')) return null;
  if (!preg_match('/pm2\s+restart\s+qqbot/iu', $msg)) return null;
  // 提取全部 wget -O <zip> <url>（兼容 -O 在前/在后、zip 名带目录如 /tmp/up.zip、URL 加引号）
  if (!preg_match_all('/wget(?:\s+-O\s*)?\s*["\']?([A-Za-z0-9._\-\/]+?\.zip)["\']?\s+["\']?(https?:\/\/[^\s"\']+)["\']?/iu', $msg, $mm, PREG_SET_ORDER)) return null;
  $steps = array();
  $seen = array();
  foreach ($mm as $g) {
    // zip 名可能带目录前缀（用户习惯 -O /tmp/up.zip），统一取纯文件名，下载到更新数据目录
    $zip = basename($g[1]);
    $url = preg_replace('/["\']+$/u', '', trim($g[2]));
    if ($url === '' || preg_match('/^https?:\/\//i', $url) !== 1) continue;
    $k = $url . '#' . $zip;
    if (isset($seen[$k])) continue;
    $seen[$k] = true;
    $steps[] = array(
      'zip' => $zip,
      'url' => $url,
      'kind' => stripos($zip, 'patch') !== false ? '补丁包' : '全量包',
    );
  }
  if (count($steps) === 0) return null;
  return array('steps' => $steps);
}

// 形似终端更新命令：含 cd/wget/unzip/pm2 restart/.zip 等特征但未通过解析 → 用于给超主提示
function 形似终端更新命令($msg) {
  $msg = 归一化终端文本($msg);
  if ($msg === '') return false;
  if (preg_match('/cd\s+\S+/iu', $msg) && preg_match('/wget/iu', $msg) && preg_match('/\.zip/iu', $msg)) return true;
  if (preg_match('/unzip/iu', $msg) && preg_match('/pm2\s+restart/iu', $msg)) return true;
  if (preg_match('/wget/iu', $msg) && preg_match('/pm2\s+restart/iu', $msg)) return true;
  return false;
}

