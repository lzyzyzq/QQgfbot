import { Router, type Request, type Response } from 'express';
import type { Logger } from '../logger';
import { requireSuperMaster } from '../middleware';
import { resolveMaxBots } from '../config';
import type { AdminAuth } from '../auth';
import type { BotRegistry } from '../registry';
import { getBot, getBotInstance } from '../../core/bot';
import { querySystemLogs, querySystemLogsCount, deleteSystemLogs, clearSystemLogs, getDb, getConfig, setConfig } from '../../db/index';
import { getBlocklist, addBlocked, removeBlocked } from '../../core/blocklist';
import { isUsingDefaultChannel } from '../email';
import {
  getSwitchStates,
  setSwitchState,
  listScheduleTasks,
  createScheduleTask,
  updateScheduleTask,
  deleteScheduleTask,
  toggleScheduleTask,
} from '../../shared/bot-controls';
import {
  BROADCAST_URLS,
  loadBroadcastCatalog,
  loadBroadcastTaskById,
  runBroadcastNow,
  syncBroadcastSchedules,
} from '../../core/broadcast';
import fs from 'fs';
import path from 'path';
import net from 'net';
import { spawn, execFileSync } from 'child_process';
import os from 'os';
import multer from 'multer';

// 部署终端会话当前目录（默认 /var/www/php，面板「部署终端」页面维护，单实例共享）
let terminalCwd = '/var/www/php';

// 云端广播异步任务（面板「立即广播」后台逐群发送，避免长请求被网关超时断连）
const broadcastJobStore = new Map<string, any>();

// ================= 服务端更新接收端（AI 发布包一键接收部署，与「更新系统」记录/重启串联） =================
const updateRecDir = (): string => path.resolve(process.cwd(), 'data', 'database', '更新');
// 云端更新配置（update-config.json）多候选源：GitHub raw 主仓 → GitHub Pages 门户 → 加速镜像 → AI 服务器 8091。
// 顺序仅为声明清单，请求前会 HEAD 测速自动按最快源重排（speedRank），任一源不可达自动切下一家，全部失败才回退本机面板配置。
const DEFAULT_AI_CONFIG_URLS = [
  'https://raw.githubusercontent.com/lzyzyzq/QQgfbot/main/update-config.json',
  'https://lzyzyzq.github.io/QQgfbot/update-config.json',
  'https://raw.gitmirror.com/lzyzyzq/QQgfbot/main/update-config.json',
  'https://8091-6f61dc7363389b7a.monkeycode-ai.online/update-config.json',
];
// 更新配置 JSON 候选地址（去重）：先本机配置 update.config_url（可逗号分隔多个），否则用默认清单
function aiConfigUrls(): string[] {
  const urls: string[] = [];
  const cfg = cfgSafe('update.config_url').split(',').map((s: string) => s.trim()).filter(Boolean);
  for (const u of [...cfg, ...DEFAULT_AI_CONFIG_URLS]) {
    if (u && urls.indexOf(u) < 0) urls.push(u);
  }
  return urls;
}

// getConfig 容错：面板进程已 initDb 正常读取；无 db 上下文（如外部调用接收函数）时返回空，不抛错
export function cfgSafe(key: string): string {
  try { return getConfig(key) || ''; } catch { return ''; }
}

// 解压根目录：优先 config update.receive_root，留空=面板运行目录（服务器部署时通常即 /var/www/php）
const receiverRoot = (): string => path.resolve(cfgSafe('update.receive_root') || process.cwd());

function fmtTime(d: Date): string {
  const p = (n: number) => String(n).padStart(2, '0');
  const now = new Date(d.getTime() + (8 * 60 + d.getTimezoneOffset()) * 60000);
  return `${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}:${p(now.getMinutes())}:${p(now.getSeconds())}`;
}

// 追加更新记录 + 更新当前版本（与群内「更新系统」插件/面板「记录本次更新」同一记录文件）
export function appendUpdateRecord(version: string, type: string, content: string, dir?: string): { records: any[]; currentVersion: string } {
  const recDir = dir || updateRecDir();
  if (!fs.existsSync(recDir)) fs.mkdirSync(recDir, { recursive: true });
  const recFile = path.join(recDir, '记录.json');
  const stateFile = path.join(recDir, '状态.json');
  let records: any[] = [];
  if (fs.existsSync(recFile)) {
    const j = JSON.parse(fs.readFileSync(recFile, 'utf-8') || '[]');
    if (Array.isArray(j)) records = j;
  }
  const time = fmtTime(new Date());
  records.push({ type, version, time, content });
  fs.writeFileSync(recFile, JSON.stringify(records, null, 2), 'utf-8');
  fs.writeFileSync(stateFile, JSON.stringify({ version, updatedAt: time }, null, 2), 'utf-8');
  return { records, currentVersion: version };
}

export function runSh(cwd: string, cmd: string, timeoutMs = 30000): Promise<{ code: number; out: string }> {
  return new Promise((resolve) => {
    let out = '';
    try {
      const child = spawn('sh', ['-c', cmd], { cwd, env: { ...process.env }, stdio: ['ignore', 'pipe', 'pipe'] });
      const timer = setTimeout(() => { try { child.kill('SIGKILL'); } catch { /* noop */ } }, timeoutMs);
      child.stdout!.on('data', (d: Buffer) => {
        out += d.toString();
        if (out.length > 200000) { try { child.kill('SIGKILL'); } catch { /* noop */ } }
      });
      child.stderr!.on('data', (d: Buffer) => { out += d.toString(); });
      child.on('error', (e: Error) => { clearTimeout(timer); resolve({ code: 127, out: out + '\n' + e.message }); });
      child.on('close', (code: number | null) => { clearTimeout(timer); resolve({ code: code ?? -1, out }); });
    } catch (e: any) {
      resolve({ code: 127, out: String((e && e.message) || e) });
    }
  });
}

async function fetchJson(url: string, timeoutMs = 8000): Promise<any> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const r = await fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': 'qq-bot-update-receiver' } });
    clearTimeout(timer);
    if (!r.ok) return null;
    return await r.json();
  } catch {
    return null;
  }
}

// 对候选源做 HEAD 测速：返回「按延迟升序 + 不可用/HEAD 不支持者兜底尾部」的 URL 列表。
// 服务器在拉补丁/全量/插件时据此先测速择优（GitHub Pages / GitHub Release / 加速镜像 / AI 服务器 8091），
// 测不出或全失败时仍按原序逐个 GET 兜底，保证任何源挂了都会自动切下一家。
async function headLatency(url: string, timeoutMs: number): Promise<number | null> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const start = Date.now();
  try {
    const r = await fetch(url, { method: 'HEAD', redirect: 'follow', signal: ctrl.signal, headers: { 'User-Agent': 'qq-bot-update-receiver' } });
    clearTimeout(timer);
    if (r.ok) return Date.now() - start;
    return null;
  } catch {
    clearTimeout(timer);
    return null;
  }
}

async function speedRank(urls: string[], timeoutMs = 5000): Promise<string[]> {
  const arr = Array.from(new Set((urls || []).filter((u) => u && String(u).trim())));
  if (arr.length < 2) return arr;
  const result = await Promise.all(arr.map(async (u) => ({ u, ms: await headLatency(u, timeoutMs) })));
  const ok = result.filter((x) => x.ms != null).sort((a, b) => (a.ms as number) - (b.ms as number)).map((x) => x.u);
  const bad = result.filter((x) => x.ms == null).map((x) => x.u);
  return ok.concat(bad);
}

async function fetchBuffer(url: string, timeoutMs = 180000): Promise<Buffer | null> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': 'qq-bot-update-receiver' } });
    if (!r.ok || !r.body) return null;
    const chunks: Buffer[] = [];
    for await (const c of r.body as any) chunks.push(Buffer.from(c));
    if (chunks.length === 0) return null;
    return Buffer.concat(chunks);
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// 拉取云端更新配置：对候选源 HEAD 测速择优，再依次取第一份可用；解析主源 + mirrors 备用源列表
async function fetchAiConfig(): Promise<any> {
  const urls = await speedRank(aiConfigUrls());
  const errors: string[] = [];
  for (const u of urls) {
    const j = await fetchJson(u);
    if (j && j.ok) {
      const sources: { name: string; patchUrl: string; fullUrl: string }[] = [];
      const push = (name: string, patchUrl: any, fullUrl: any) => {
        const p = String(patchUrl || '').trim();
        const f = String(fullUrl || '').trim();
        if (p || f) sources.push({ name, patchUrl: p, fullUrl: f });
      };
      push('主源（GitHub Release）', j.patchUrl, j.fullUrl);
      const mirrors = Array.isArray(j.mirrors) ? j.mirrors : [];
      for (const m of mirrors) {
        if (m) push(String((m as any).name || '备用源'), (m as any).patchUrl, (m as any).fullUrl);
      }
      if (sources.length === 0) { errors.push(u + '：未找到下载地址'); continue; }
      const prim = sources[0];
      return {
        ok: true,
        sourceUrl: u,
        errors,
        version: String(j.version || ''),
        changeLog: String(j.changeLog || ''),
        patchUrl: prim.patchUrl,
        fullUrl: prim.fullUrl,
        sources,
      };
    }
    errors.push(u + '：不可用');
  }
  return { ok: false, sourceUrl: '', errors };
}

export async function receiveUpdatePackage(opts: {
  zipBuffer?: Buffer;
  zipUrl?: string;
  zipUrls?: string[];  // 多候选下载地址：按序尝试，取第一个可下载的源（GitHub 主源失败自动切加速镜像/备用源）
  zipName?: string;
  changeLog?: string;
  root?: string;      // 解压根目录（默认 update.receive_root 或面板运行目录）
  dataDir?: string;   // 更新记录目录（默认 面板运行目录/data/database/更新），测试可隔离
}): Promise<any> {
  const root = opts.root || receiverRoot();
  const recDir = opts.dataDir || updateRecDir();
  if (!fs.existsSync(root)) fs.mkdirSync(root, { recursive: true });
  const zipTmp = path.join(os.tmpdir(), `qqbot-recv-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.zip`);
  try {
    // 1. 得到 zip 内容（多候选 URL 下载 或 本地上传）
    let data: Buffer | null = null;
    let usedUrl = '';
    const urls: string[] = opts.zipUrls && opts.zipUrls.length ? opts.zipUrls : (opts.zipUrl ? [opts.zipUrl] : []);
    if (urls.length > 0) {
      // 多候选源先 HEAD 测速按最快排序再下载；失败仍逐个兜底
      const ordered = await speedRank(urls);
      for (const u of ordered) {
        const b = await fetchBuffer(u);
        if (b) { data = b; usedUrl = u; break; }
      }
      if (!data) return { ok: false, step: '下载', error: `下载失败（已测速并按序尝试 ${ordered.length} 个源：${ordered.join(' → ')}，均不可访问或超时）` };
    } else if (opts.zipBuffer && opts.zipBuffer.length > 0) {
      data = opts.zipBuffer;
    } else {
      return { ok: false, step: '参数', error: '缺少 zip 文件或下载地址' };
    }
    // zip 魔数校验
    if (data.length < 4 || data[0] !== 0x50 || data[1] !== 0x4b) {
      return { ok: false, step: '校验', error: '不是有效的 ZIP 文件' };
    }
    fs.writeFileSync(zipTmp, data);
    // 文件名：优先取实际下载 URL 的文件名（源/镜像文件名一致），无则用入参
    let zipName = String(opts.zipName || '');
    if ((!zipName || zipName === 'update.zip') && usedUrl) {
      try { zipName = decodeURIComponent(usedUrl.split('?')[0].split('/').pop() || zipName); } catch { /* noop */ }
    }
    // 2. 版本与类型：从文件名提取（如 qqbot-card-editor-patch-4.2.59.zip）
    const m = zipName.match(/(\d+(?:\.\d+){1,3})/);
    const version = m ? m[1] : (cfgSafe('update.version') || '4.2.59');
    const kind = /full|全量/i.test(zipName) ? '全量包' : '补丁包';
    // 3. 压缩包完整性校验
    const t = await runSh(root, `unzip -t ${JSON.stringify(zipTmp)}`);
    if (t.code !== 0) {
      return { ok: false, step: '校验', error: `压缩包校验失败（服务器未安装 unzip 或文件损坏）：\n${t.out.slice(0, 300)}` };
    }
    // 4. 解压到部署根目录（覆盖式，与群内「更新补丁/更新全量」一致）
    const u = await runSh(root, `unzip -o ${JSON.stringify(zipTmp)}`);
    if (u.code !== 0) {
      return { ok: false, step: '解压', error: `解压失败：\n${u.out.slice(0, 300)}` };
    }
    // 5. 记录版本 + 更新内容（写 记录.json / 状态.json，群内「更新记录」与「检查更新」立即可见）
    const content = (opts.changeLog && opts.changeLog.trim()) || cfgSafe('update.changelog') || '';
    const rec = appendUpdateRecord(version, `服务端接收-${kind}`, content || `接收更新包：${zipName}`, recDir);
    // 6. 重启机器人（pm2 restart qqbot；部署根=面板运行目录）
    const restartCwd = opts.root || process.cwd();
    const rcmd = `cd ${JSON.stringify(restartCwd)} && pm2 restart qqbot`;
    const r = await runSh(restartCwd, rcmd, 15000);
    return {
      ok: true,
      kind,
      version,
      fileName: zipName,
      usedUrl,
      root,
      applied: true,
      records: rec.records,
      currentVersion: rec.currentVersion,
      restart: { ok: r.code === 0, output: r.out.slice(0, 300) },
    };
  } finally {
    try { if (fs.existsSync(zipTmp)) fs.unlinkSync(zipTmp); } catch { /* noop */ }
  }
}

// 检测目标端口是否已被其他进程占用（排除服务自身当前端口）
function portInUse(p: number, currentPort: number): Promise<boolean> {
  return new Promise((resolve) => {
    if (p === currentPort) { resolve(false); return; }
    const srv = net.createServer();
    srv.once('error', () => resolve(true));
    srv.once('listening', () => { srv.close(() => resolve(false)); });
    srv.listen(p, '0.0.0.0');
  });
}

interface BotConfig {
  appId?: string;
  clientSecret?: string;
  sandbox?: boolean;
  intents?: number;
}

interface AdminConfig {
  port: number;
}

export function createSystemRoutes(
  logger: Logger,
  botConfig: BotConfig,
  adminConfig: AdminConfig,
  getUpdateLog: () => string,
  saveUpdateLog?: (content: string) => void,
  restartFn?: () => Promise<any>,
  refreshFn?: () => Promise<void>,
  adminAuth?: AdminAuth,
  botRegistry?: BotRegistry,
): Router {
  const router = Router();

  router.get('/logs', (_req: Request, res: Response) => {
    const lines = Number(_req.query.lines) || 200;
    res.json(logger.readLogs(lines));
  });

  router.get('/logs/download', (_req: Request, res: Response) => {
    res.download(logger.getLogPath());
  });

  // 系统日志数据库查询（运行记录）：非超主只能看到自己名下机器人的记录；超主可传 bot_id 过滤
  router.get('/system-logs', (_req: Request, res: Response) => {
    const limit = Number(_req.query.limit) || 100;
    const category = _req.query.category as string | undefined;
    const level = _req.query.level as string | undefined;
    const botId = (_req.query.bot_id as string) || '';
    const user = (_req as any).adminUser as { username?: string; role?: string } | undefined;
    let botIds: string[] | undefined;
    if (botId) {
      botIds = [botId];
    } else if (user && user.role !== 'super_master' && botRegistry) {
      // 运行记录日志按 appId 存储（BotCore.getBotId），这里需把名下机器人的 id 与 appId 都纳入，否则过滤会漏掉记录
      const owned: string[] = [];
      for (const b of botRegistry.list(user.username)) {
        owned.push(b.id);
        if (b.appId) owned.push(b.appId);
      }
      botIds = [...new Set(owned)];
    }
    const logs = querySystemLogs(limit, category, level, botIds);
    const total = querySystemLogsCount(category, level, botIds);
    // 每条记录标注来源机器人：按 appId 或注册 id 反查名称，便于区分是哪台机器人发出的错误
    let botNameMap = new Map<string, string>();
    try {
      for (const b of botRegistry ? botRegistry.list() : []) {
        if (b.name) {
          if (b.id && !botNameMap.has(b.id)) botNameMap.set(b.id, String(b.name));
          if (b.appId && !botNameMap.has(String(b.appId))) botNameMap.set(String(b.appId), String(b.name));
        }
      }
    } catch {}
    const enriched = (logs as any[]).map((l) => ({
      ...l,
      bot_name: l.bot_id ? (botNameMap.get(String(l.bot_id)) || '') : '',
    }));
    res.json({ logs: enriched, total, filtered: !!botIds });
  });

  // ===== 封用户黑名单（超主）：config KV 持久化，webhook 消息入口命中即丢弃 =====
  router.get('/blocklist', (_req, res) => {
    res.json({ list: getBlocklist() });
  });
  router.post('/blocklist', requireSuperMaster, (req: Request, res: Response) => {
    const ids: string[] = Array.isArray(req.body?.ids) ? req.body.ids.map(String) : (req.body?.id ? [String(req.body.id)] : []);
    if (!ids.length) { res.status(400).json({ error: '缺少 id' }); return; }
    ids.forEach((id) => addBlocked(id));
    res.json({ ok: true, list: getBlocklist() });
  });
  router.delete('/blocklist/:id', requireSuperMaster, (req: Request, res: Response) => {
    removeBlocked(decodeURIComponent(req.params.id));
    res.json({ ok: true, list: getBlocklist() });
  });

  // 删除运行记录：body {ids:[...]} 批量删除；?all=1 或 body {all:true} 清空全部
  router.delete('/system-logs', requireSuperMaster, (req: Request, res: Response) => {
    try {
      const ids = req.body?.ids;
      if (Array.isArray(ids)) {
        const deleted = deleteSystemLogs(ids.map(Number));
        res.json({ ok: true, deleted });
        return;
      }
      if (req.query.all === '1' || req.body?.all) {
        const deleted = clearSystemLogs();
        res.json({ ok: true, deleted });
        return;
      }
      res.status(400).json({ error: '缺少 ids 或 all 参数' });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // ===== 邮件服务（SMTP）配置：仅超级主人 =====
  router.get('/smtp', requireSuperMaster, (_req: Request, res: Response) => {
    const configured = Boolean(String(getConfig('smtp.host') || '').trim() && String(getConfig('smtp.user') || '').trim() && String(getConfig('smtp.pass') || '').trim());
    res.json({
      configured,
      useDefault: isUsingDefaultChannel(),
      host: getConfig('smtp.host') || '',
      port: getConfig('smtp.port') || 465,
      secure: String(getConfig('smtp.secure') || '') === '1',
      user: getConfig('smtp.user') || '',
      pass: configured ? '******' : '',
      from: getConfig('smtp.from') || '',
      senderName: getConfig('smtp.senderName') || getConfig('smtp.default.senderName') || 'QQ Bot 面板',
    });
  });

  router.put('/smtp', requireSuperMaster, (req: Request, res: Response) => {
    const { host, port, secure, user, pass, from, senderName } = req.body || {};
    if (!String(host || '').trim() || !String(user || '').trim() || !String(pass || '').trim()) {
      res.status(400).json({ error: 'host、user、pass 均必填' });
      return;
    }
    try {
      setConfig('smtp.host', String(host).trim());
      setConfig('smtp.port', String(Math.trunc(Number(port) || 465)));
      setConfig('smtp.secure', secure ? '1' : '0');
      setConfig('smtp.user', String(user).trim());
      setConfig('smtp.pass', String(pass).trim());
      setConfig('smtp.from', String(from || '').trim());
      if (senderName !== undefined) setConfig('smtp.senderName', String(senderName).trim());
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  router.post('/smtp/test', requireSuperMaster, async (req: Request, res: Response) => {
    const to = String(req.body?.to || '').trim();
    if (!to) { res.status(400).json({ error: '请填写测试收件邮箱' }); return; }
    try {
      const { sendTestMail } = await import('../email');
      await sendTestMail(to);
      res.json({ ok: true, message: '测试邮件已发送，请查收' });
    } catch (e: any) {
      res.status(500).json({ error: '发送失败：' + (e.message || '未知错误') });
    }
  });

  router.get('/updatelog', (_req: Request, res: Response) => {
    res.json({ content: getUpdateLog() });
  });

  router.put('/updatelog', requireSuperMaster, (req: Request, res: Response) => {
    const content = req.body?.content;
    if (typeof content !== 'string') {
      res.status(400).json({ error: '缺少 content 字段' });
      return;
    }
    if (!saveUpdateLog) {
      res.status(500).json({ error: '更新日志保存能力不可用' });
      return;
    }
    try {
      saveUpdateLog(content);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 面板授权码登录开关状态（免鉴权，供登录页显示/隐藏授权码登录入口）
  router.get('/panel-login-status', (_req: Request, res: Response) => {
    res.json({ enabled: (getConfig('panel.auth_code_login') || '1') === '1' });
  });

  router.get('/config', (req: Request, res: Response) => {
    res.json({
      appId: botConfig.appId,
      clientSecret: '******',
      sandbox: botConfig.sandbox,
      intents: botConfig.intents,
      adminPort: adminConfig.port,
      serverPort: getConfig('server.port') || String(adminConfig.port),
      panelHost: getConfig('panel.host') || '',
      authCodePanelLogin: (getConfig('panel.auth_code_login') || '1') === '1',
      licenseAutoShutdown: (getConfig('license.auto_shutdown') || '1') === '1',
      botName: getConfig('bot.name') || '',
      chimeTexts: getConfig('bot.chime_texts') || '',
      chimeCity: getConfig('bot.chime_city') || '北京',
      chimeAd: getConfig('bot.chime_ad') || '',
      weatherTextApi: getConfig('bot.weather_text_api') || '',
      weatherPngApi: getConfig('bot.weather_png_api') || '',
      footerText: getConfig('bot.footer_text') || '',
      footerAds: getConfig('bot.footer_ads') || '',
      qqLoginToken: getConfig('qqlogin.token') || '',
      updateVersion: getConfig('update.version') || '4.2.65',
      updatePatchUrl: getConfig('update.patch_url') || 'https://8091-6f61dc7363389b7a.monkeycode-ai.online/qqbot-card-editor-patch-4.2.65.zip',
      updateFullUrl: getConfig('update.full_url') || '',
      updateFrameworkPatchUrl: getConfig('update.framework_patch_url') || '',
      updatePluginPatchUrl: getConfig('update.plugin_patch_url') || '',
      updateFrameworkFullUrl: getConfig('update.framework_full_url') || '',
      updatePluginFullUrl: getConfig('update.plugin_full_url') || '',
      updateChangeLog: getConfig('update.changelog') || '',
      updateConfigUrl: getConfig('update.config_url') || '',
    });
  });

  router.put('/config', requireSuperMaster, async (req: Request, res: Response) => {
    if (req.body.appId) { botConfig.appId = req.body.appId; setConfig('bot.app_id', req.body.appId); }
    if (req.body.clientSecret && req.body.clientSecret !== '******') {
      botConfig.clientSecret = req.body.clientSecret;
      setConfig('bot.app_secret', req.body.clientSecret);
      try { getBot().updateSecret(req.body.clientSecret); } catch (e: any) {}
    }
    if (req.body.sandbox !== undefined) botConfig.sandbox = req.body.sandbox;
    if (req.body.intents) botConfig.intents = req.body.intents;
    if (req.body.port !== undefined) {
      const p = parseInt(String(req.body.port), 10);
      if (p > 0 && p <= 65535) {
        // 目标端口已被其他进程（如 nginx/tailscale 的 6655）占用时拒绝保存，避免重启后 502
        if (await portInUse(p, adminConfig.port)) {
          res.status(409).json({ error: `端口 ${p} 已被其他进程占用（可能是 nginx/访问端口）。请改为内部服务端口（如 3000/3100），不要填访问端口 6655` });
          return;
        }
        setConfig('server.port', String(p));
      }
    }
    if (req.body.authCodePanelLogin !== undefined) setConfig('panel.auth_code_login', req.body.authCodePanelLogin ? '1' : '0');
    if (req.body.panelHost !== undefined) setConfig('panel.host', String(req.body.panelHost).trim());
    if (req.body.licenseAutoShutdown !== undefined) setConfig('license.auto_shutdown', req.body.licenseAutoShutdown ? '1' : '0');
    if (req.body.botName !== undefined) setConfig('bot.name', String(req.body.botName).trim());
    if (req.body.chimeTexts !== undefined) setConfig('bot.chime_texts', String(req.body.chimeTexts));
    if (req.body.chimeCity !== undefined) setConfig('bot.chime_city', String(req.body.chimeCity).trim() || '北京');
    if (req.body.chimeAd !== undefined) setConfig('bot.chime_ad', String(req.body.chimeAd));
    if (req.body.weatherTextApi !== undefined) setConfig('bot.weather_text_api', String(req.body.weatherTextApi).trim());
    if (req.body.weatherPngApi !== undefined) setConfig('bot.weather_png_api', String(req.body.weatherPngApi).trim());
    if (req.body.footerText !== undefined) setConfig('bot.footer_text', String(req.body.footerText));
    if (req.body.footerAds !== undefined) setConfig('bot.footer_ads', String(req.body.footerAds));
    if (req.body.qqLoginToken !== undefined) setConfig('qqlogin.token', String(req.body.qqLoginToken).trim());
    if (req.body.updateVersion !== undefined) setConfig('update.version', String(req.body.updateVersion).trim() || '4.2.59');
    if (req.body.updatePatchUrl !== undefined) setConfig('update.patch_url', String(req.body.updatePatchUrl).trim());
    if (req.body.updateFullUrl !== undefined) setConfig('update.full_url', String(req.body.updateFullUrl).trim());
    if (req.body.updateFrameworkPatchUrl !== undefined) setConfig('update.framework_patch_url', String(req.body.updateFrameworkPatchUrl).trim());
    if (req.body.updatePluginPatchUrl !== undefined) setConfig('update.plugin_patch_url', String(req.body.updatePluginPatchUrl).trim());
    if (req.body.updateFrameworkFullUrl !== undefined) setConfig('update.framework_full_url', String(req.body.updateFrameworkFullUrl).trim());
    if (req.body.updatePluginFullUrl !== undefined) setConfig('update.plugin_full_url', String(req.body.updatePluginFullUrl).trim());
    if (req.body.updateChangeLog !== undefined) setConfig('update.changelog', String(req.body.updateChangeLog));
    if (req.body.updateConfigUrl !== undefined) setConfig('update.config_url', String(req.body.updateConfigUrl).trim());
    res.json({ ok: true });
  });

  // 更新系统：读取更新记录列表 + 当前部署版本 + 记录文件路径
  router.get('/update-records', (_req: Request, res: Response) => {
    try {
      const dir = path.resolve(process.cwd(), 'data', 'database', '更新');
      const recFile = path.join(dir, '记录.json');
      const stateFile = path.join(dir, '状态.json');
      let records: any[] = [];
      if (fs.existsSync(recFile)) {
        const j = JSON.parse(fs.readFileSync(recFile, 'utf-8') || '[]');
        if (Array.isArray(j)) records = j;
      }
      let currentVersion = '';
      if (fs.existsSync(stateFile)) {
        const s = JSON.parse(fs.readFileSync(stateFile, 'utf-8') || '{}');
        currentVersion = String(s.version || '');
      }
      res.json({ ok: true, records, currentVersion, recordFile: recFile });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  // 更新系统：手动补记本次更新（用于手动部署后把版本写入升级列表与当前版本）
  router.post('/record-update', requireSuperMaster, (_req: Request, res: Response) => {
    try {
      const version = (getConfig('update.version') || '4.2.59').trim();
      const changelog = getConfig('update.changelog') || '';
      const rec = appendUpdateRecord(version, '手动记录', changelog);
      res.json({ ok: true, records: rec.records, currentVersion: version });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  router.post('/refresh', async (_req: Request, res: Response) => {
    try {
      if (refreshFn) {
        await refreshFn();
        res.json({ ok: true, message: 'Bot refreshed' });
      } else {
        res.status(400).json({ error: 'Refresh not supported' });
      }
    } catch (err) {
      res.status(500).json({ error: String(err) });
    }
  });

  router.post('/restart', requireSuperMaster, async (_req: Request, res: Response) => {
    try {
      if (!restartFn) {
        res.status(400).json({ error: 'Restart not supported' });
        return;
      }
      const r: any = await restartFn();
      if (r && r.ok === false) {
        res.status(500).json({ ok: false, error: (r.err || '远程重启失败').slice(0, 300) });
        return;
      }
      res.json({ ok: true, message: '重启命令已执行', detail: r || {} });
    } catch (err) {
      res.status(500).json({ error: String(err) });
    }
  });

  // 部署终端：面板内嵌的命令终端，会话 cwd 默认 /var/www/php（部署根目录），
  // 支持 cd 切换目录（会话内持久），其余命令在会话 cwd 下用 sh -c 执行。
  // 仅超级主人可调用（配合 admin token），与面板公网访问（6655 反代）兼容。
  router.post('/terminal/exec', requireSuperMaster, async (req: Request, res: Response) => {
    const cmd = String((req.body && req.body.command) || '').trim();
    const home = os.homedir() || '/root';
    const resolveDir = (raw: string): string => {
      let t = String(raw).trim().replace(/^['"]|['"]$/g, '');
      if (!t) return terminalCwd;
      if (t === '~') t = home;
      else if (t.startsWith('~/')) t = path.join(home, t.slice(2));
      return path.resolve(terminalCwd, t);
    };
    try {
      if (!cmd) {
        res.json({ ok: true, cwd: terminalCwd, output: '', code: 0 });
        return;
      }
      // 纯 cd 命令：切换会话目录（cd / cd ~ / cd <dir>）
      const cdMatch = cmd.match(/^cd(\s+\S.*)?$/);
      if (cdMatch) {
        const target = (cdMatch[1] || '').trim() || terminalCwd;
        const resolved = resolveDir(target);
        if (!fs.existsSync(resolved)) {
          res.json({ ok: true, cwd: terminalCwd, output: `cd: 无此目录：${target}`, code: 1 });
          return;
        }
        const st = fs.statSync(resolved);
        if (!st.isDirectory()) {
          res.json({ ok: true, cwd: terminalCwd, output: `cd: 不是目录：${target}`, code: 1 });
          return;
        }
        terminalCwd = resolved;
        res.json({ ok: true, cwd: terminalCwd, output: '', code: 0 });
        return;
      }
      const timeout = Math.min(parseInt(String((req.body && req.body.timeout) || '30000'), 10) || 30000, 120000);
      const child = spawn('sh', ['-c', cmd], {
        cwd: terminalCwd,
        env: { ...process.env, TERM: 'xterm', HOME: home },
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      let out = '';
      let err = '';
      child.stdout!.on('data', (d: Buffer) => {
        out += d.toString();
        if (out.length > 300000) { try { child.kill('SIGKILL'); } catch {} }
      });
      child.stderr!.on('data', (d: Buffer) => { err += d.toString(); });
      const timer = setTimeout(() => {
        try { child.kill('SIGTERM'); } catch {}
        setTimeout(() => { try { child.kill('SIGKILL'); } catch {} }, 2000);
      }, timeout);
      child.on('error', (e: Error) => {
        clearTimeout(timer);
        res.json({ ok: true, cwd: terminalCwd, output: ((out + err).trim() ? (out + '\n' + err).trim() : '') + `\n[错误] ${e.message}`, code: 127 });
      });
      child.on('close', (code: number | null) => {
        clearTimeout(timer);
        res.json({ ok: true, cwd: terminalCwd, output: (out + err).trim() || '(无输出)', code: code == null ? -1 : code });
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e && e.message || e) });
    }
  });

  // 部署终端「拉取 GitHub 项目」：将会话目录源码与远程 Git 仓库强制同步（覆盖本地未提交改动，
  // 忽略文件如 data/node_modules/dist 不受影响）。mode: pull 仅拉取 / build +npm安装构建 / restart +pm2重启
  router.post('/git-pull', requireSuperMaster, async (req: Request, res: Response) => {
    const repo = String((req.body && req.body.repo) || '').trim() || 'https://github.com/lzyzyzq/QQgfbot.git';
    const branch = String((req.body && req.body.branch) || '').trim() || 'main';
    const mode = String((req.body && req.body.mode) || '').trim() || 'pull';
    if (!/^[A-Za-z0-9@._:\/~+-]+$/.test(repo)) {
      res.json({ ok: true, code: 2, output: '仓库地址不合法（仅支持 http(s)/git@/ssh:// 字符）' });
      return;
    }
    if (!/^[A-Za-z0-9_.\/-]+$/.test(branch)) {
      res.json({ ok: true, code: 2, output: '分支名不合法' });
      return;
    }
    try {
      const cwd = terminalCwd;
      if (!fs.existsSync(cwd)) fs.mkdirSync(cwd, { recursive: true });
      const sd = `git -c safe.directory=${JSON.stringify(cwd)}`;
      const qRepo = JSON.stringify(repo);
      const qBranch = JSON.stringify(branch);
      const steps: string[] = [];
      steps.push(`set +e`);
      steps.push(`echo "=== 目标目录: ${JSON.stringify(cwd)} ==="`);
      steps.push(`if ! ${sd} rev-parse --git-dir >/dev/null 2>&1; then echo "=== 目录尚无 git，正在初始化 ==="; git init -q; fi`);
      steps.push(`if [ "$(${sd} remote get-url origin 2>/dev/null)" != ${qRepo} ]; then ${sd} remote set-url origin ${qRepo} 2>/dev/null || ${sd} remote add origin ${qRepo}; echo "=== 远端已指向 ${qRepo} ==="; fi`);
      steps.push(`${sd} fetch --depth=1 origin ${qBranch}`);
      steps.push(`${sd} reset --hard origin/${qBranch}`);
      steps.push(`echo "=== 已同步到分支 ${qBranch} 最新提交 ==="`);
      steps.push(`${sd} log -1 --format="commit: %h%n%s%n同步时间: %ci"`);
      if (mode === 'build' || mode === 'restart') {
        steps.push(`if [ -f package.json ]; then`);
        steps.push(`  echo "=== 安装依赖（npm ci / npm install）===";`);
        steps.push(`  if [ -f package-lock.json ]; then npm ci --no-audit --no-fund 2>&1 | tail -4; else npm install --no-audit --no-fund 2>&1 | tail -4; fi`);
        steps.push(`  echo "=== 编译（tsc → dist）===";`);
        steps.push(`  npm run build 2>&1 | tail -20`);
        steps.push(`  echo "=== 精简生产依赖 ===";`);
        steps.push(`  npm prune --omit=dev 2>&1 | tail -3`);
        steps.push(`else`);
        steps.push(`  echo "（当前目录不是 qqbot 源码根，跳过安装/构建）";`);
        steps.push(`fi`);
      }
      if (mode === 'restart') {
        steps.push(`echo "=== pm2 restart qqbot ===";`);
        steps.push(`cd ${JSON.stringify(cwd)} && (pm2 restart qqbot 2>&1 || echo "pm2 qqbot 不存在/不可用，请手动重启")`);
      }
      steps.push(`echo "=== 完成（退出码 $?）==="`);
      const timeout = mode === 'pull' ? 180000 : 600000;
      const r = await runSh(cwd, steps.join('\n'), timeout);
      res.json({ ok: true, code: r.code, output: r.out || '(无输出)' });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: String(e && e.message || e) });
    }
  });

  // CPU 采样（两次请求间隔 delta，前端每 10s 轮询）：首次返回 null 由前端显示"采样中"
  let cpuLast: { at: number; idle: number; total: number } | null = null;
  function cpuPercent(): number | null {
    try {
      const cpus = os.cpus();
      let idle = 0;
      let total = 0;
      for (const c of cpus) {
        const t = c.times as Record<string, number>;
        total += t.user + t.nice + t.sys + t.idle + t.irq;
        idle += t.idle;
      }
      const now = Date.now();
      if (cpuLast) {
        const dTotal = total - cpuLast.total;
        const dIdle = idle - cpuLast.idle;
        cpuLast = { at: now, idle, total };
        if (dTotal > 0) {
          const p = Math.round((1 - dIdle / dTotal) * 100);
          return Math.max(0, Math.min(100, p));
        }
        return 0;
      }
      cpuLast = { at: now, idle, total };
      return null;
    } catch { return null; }
  }

  function diskOf(p: string): { totalMb: number; usedMb: number; percent: number } | null {
    try {
      const s = fs.statfsSync(p);
      const total = Number(s.blocks) * Number(s.bsize);
      const avail = Number(s.bavail) * Number(s.bsize);
      const used = total - avail;
      return {
        totalMb: Math.round(total / 1048576),
        usedMb: Math.round(used / 1048576),
        percent: total > 0 ? Math.round((used / total) * 100) : 0,
      };
    } catch { return null; }
  }

  // 近 24 小时事件趋势：入站=收到消息(category message)，出站=机器人回复(category send)
  function eventTrend24(): { h: string; in: number; out: number }[] {
    const out: { h: string; in: number; out: number }[] = [];
    for (let i = 23; i >= 0; i--) {
      const d = new Date(Date.now() - i * 3600000 + 8 * 3600000);
      out.push({ h: String(d.getUTCHours()).padStart(2, '0'), in: 0, out: 0 });
    }
    try {
      const since = new Date(Date.now() - 24 * 3600000).toISOString().replace('T', ' ').slice(0, 19);
      const rows = getDb().prepare(
        "SELECT category, created_at FROM system_logs WHERE created_at >= ? AND category IN ('message','send')"
      ).all(since) as any[];
      for (const r of rows) {
        const m = / (\d{2}):/.exec(String(r.created_at || ''));
        if (!m) continue;
        const bjH = String((Number(m[1]) + 8) % 24).padStart(2, '0');
        const b = out.find((o) => o.h === bjH);
        if (b) {
          if (r.category === 'message') b.in++;
          else b.out++;
        }
      }
    } catch {}
    return out;
  }

  // 词库统计：plugins 目录下 .txt/.cid 视为词库文件，非空非注释行计为词条
  function dictStats(): { files: number; entries: number } {
    let files = 0;
    let entries = 0;
    const walk = (dir: string, depth: number): void => {
      if (depth > 5) return;
      let list: string[] = [];
      try { list = fs.readdirSync(dir); } catch { return; }
      for (const name of list) {
        if (name.startsWith('.')) continue;
        const full = path.join(dir, name);
        let st: fs.Stats | null = null;
        try { st = fs.statSync(full); } catch { continue; }
        if (st.isDirectory()) {
          if (name === 'node_modules' || name === '__pycache__') continue;
          walk(full, depth + 1);
        } else {
          const ext = path.extname(name).toLowerCase();
          if (ext !== '.txt' && ext !== '.cid') continue;
          files++;
          let text = '';
          try { text = fs.readFileSync(full, 'utf-8'); } catch { /* ignore */ }
          for (const line of text.split(/\r?\n/)) {
            const t = line.trim();
            if (!t || t.startsWith('#') || t.startsWith('//')) continue;
            entries++;
          }
        }
      }
    };
    walk(path.resolve(process.cwd(), 'plugins'), 0);
    return { files, entries };
  }

  // 消息收发统计：全量与今日（按北京时间归日）
  function messageStats(): { in: number; out: number; todayIn: number; todayOut: number } {
    const r = { in: 0, out: 0, todayIn: 0, todayOut: 0 };
    try {
      const db = getDb();
      const total = (cat: string) => Number((db.prepare('SELECT COUNT(*) AS c FROM system_logs WHERE category = ?').get(cat) as any)?.c || 0);
      const today = (cat: string) => Number((db.prepare("SELECT COUNT(*) AS c FROM system_logs WHERE category = ? AND date(created_at, '+8 hours') = date('now', '+8 hours')").get(cat) as any)?.c || 0);
      r.in = total('message');
      r.out = total('send');
      r.todayIn = today('message');
      r.todayOut = today('send');
    } catch { /* ignore */ }
    return r;
  }

  // 今日异常：error/fatal 级别日志数（按北京时间归日）
  function errorsToday(): number {
    try {
      return Number((getDb().prepare("SELECT COUNT(*) AS c FROM system_logs WHERE level IN ('error','fatal') AND date(created_at, '+8 hours') = date('now', '+8 hours')").get() as any)?.c || 0);
    } catch { return 0; }
  }

  // 近 14 天消息趋势（按北京时间归日，缺失日期补 0）
  function eventTrend14(): { label: string; in: number; out: number }[] {
    const out: { label: string; in: number; out: number }[] = [];
    const map = new Map<string, { in: number; out: number }>();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(Date.now() + 8 * 3600000 - i * 86400000);
      const key = d.toISOString().slice(0, 10);
      map.set(key, { in: 0, out: 0 });
      out.push({ label: (d.getUTCMonth() + 1) + '/' + d.getUTCDate(), in: 0, out: 0 });
    }
    try {
      const since = new Date(Date.now() - 14 * 86400000).toISOString().replace('T', ' ').slice(0, 19);
      const rows = getDb().prepare(
        "SELECT date(created_at, '+8 hours') AS d, category, COUNT(*) AS c FROM system_logs WHERE created_at >= ? AND category IN ('message','send') GROUP BY d, category"
      ).all(since) as any[];
      for (const r of rows) {
        const b = map.get(String(r.d));
        if (b) {
          if (r.category === 'message') b.in += Number(r.c) || 0;
          else b.out += Number(r.c) || 0;
        }
      }
    } catch { /* ignore */ }
    let i = 0;
    for (const v of map.values()) { out[i].in = v.in; out[i].out = v.out; i++; }
    return out;
  }

  // PM2 进程状态（仪表盘「部署进程状态」）：pm2 jlist JSON，10s 缓存；未安装 pm2 时 available:false
  let pm2Cache: { at: number; data: any } = { at: 0, data: null };
  function pm2Status(): any {
    const now = Date.now();
    if (pm2Cache.data && now - pm2Cache.at < 10000) return pm2Cache.data;
    let data: any = { available: false, processes: [] };
    try {
      const out = execFileSync('pm2', ['jlist'], { encoding: 'utf8', timeout: 6000, stdio: ['ignore', 'pipe', 'ignore'] });
      const arr = JSON.parse(out || '[]');
      const processes = (Array.isArray(arr) ? arr : []).map((p: any) => {
        const env = p.pm2_env || {};
        return {
          id: p.pm_id,
          name: p.name || '',
          status: env.status || '',
          mode: env.exec_mode || '',
          pid: env.pid || 0,
          cpu: p.monit && p.monit.cpu != null ? p.monit.cpu : 0,
          mem: p.monit && p.monit.memory ? Math.round(p.monit.memory / 1048576) : 0,
          restarts: env.restart_time || 0,
          uptime: env.pm_uptime ? Math.round((now - env.pm_uptime) / 1000) : 0,
        };
      });
      data = { available: true, processes };
    } catch { data = { available: false, processes: [] }; }
    pm2Cache = { at: now, data };
    return data;
  }

  router.get('/stats', (_req: Request, res: Response) => {
    // 统计插件数量：与插件列表页一致，按 plugins 目录实际可展示插件去重计数
    // （避免历史 DB 遗留重复记录（uuid code + file- 双实例）导致统计虚高、本地/服务器数量对不上）
    let pluginCount = 0;
    try {
      const pluginsDir = path.resolve(process.cwd(), 'plugins');
      if (fs.existsSync(pluginsDir)) {
        const names = new Set<string>();
        for (const name of fs.readdirSync(pluginsDir)) {
          if (name === '.tmp' || name.startsWith('.')) continue;
          const full = path.join(pluginsDir, name);
          let stat: fs.Stats | null = null;
          try { stat = fs.statSync(full); } catch { continue; }
          if (stat.isDirectory()) {
            const hasEntry = fs.existsSync(path.join(full, 'index.js')) ||
              fs.existsSync(path.join(full, 'index.mjs')) ||
              fs.existsSync(path.join(full, 'index.ts')) ||
              fs.existsSync(path.join(full, 'src', 'index.ts'));
            const hasManifest = fs.existsSync(path.join(full, 'plugin.json'));
            if (!hasEntry && !hasManifest) continue;
            names.add(name);
          } else {
            const ext = path.extname(name).toLowerCase();
            if (!ext || ext === '.zip' || ext === '.txt' || ext === '.md') continue;
            names.add(name);
          }
        }
        pluginCount = names.size;
      }
    } catch (e) {}

    // 读取 NapCatQQ 版本
    let napcatVersion = '';
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'external', 'NapCatQQ', 'package.json'), 'utf-8'));
      napcatVersion = pkg.version || '';
    } catch (e) {}

    // 机器人运行状态：registry 里 running 为在线（含多机器人时各自状态）
    let botEntries: any[] = [];
    try { botEntries = botRegistry ? botRegistry.list() : []; } catch {}
    let botsTotal = botEntries.length;
    let botsOnline = botEntries.filter((b) => b && b.status === 'running').length;
    // registry 未就绪（后台进程/启动早期/多进程部署）时回退按库中出现的 bot_id 计数，避免仪表盘恒显 0/0
    if (botsTotal === 0) {
      try {
        const rows = getDb().prepare(
          "SELECT DISTINCT bot_id FROM group_members WHERE bot_id IS NOT NULL AND bot_id != ''"
        ).all() as any[];
        const ids = new Set(rows.map((r: any) => String(r.bot_id)));
        botsTotal = ids.size;
        botsOnline = ids.size;
      } catch {}
    }
    let botNameMap = new Map<string, string>();
    try {
      for (const b of botEntries) {
        if (b.name) {
          if (b.id) botNameMap.set(String(b.id), String(b.name));
          if (b.appId) botNameMap.set(String(b.appId), String(b.name));
        }
      }
    } catch {}

    // 最近事件（实时 feed）：最近 12 条运行记录，附机器人名称
    let recent: any[] = [];
    try {
      recent = querySystemLogs(12).map((l: any) => ({
        id: l.id,
        level: l.level || 'info',
        category: l.category || '',
        message: String(l.message || '').slice(0, 80),
        detail: String(l.detail || '').slice(0, 120),
        bot_id: l.bot_id || '',
        bot_name: l.bot_id ? (botNameMap.get(String(l.bot_id)) || '') : '',
        group_id: l.group_id || '',
        user_id: l.user_id || '',
        created_at: l.created_at || '',
      }));
    } catch {}

    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const disk = diskOf(process.cwd());
    // 版本兜底：面板配置可能为空/过时，回退读 package.json，避免仪表盘「系统版本」恒显 '-'
    let pkgVer = '';
    try { pkgVer = String(JSON.parse(fs.readFileSync(path.join(process.cwd(), 'package.json'), 'utf-8')).version || ''); } catch {}
    // 框架版本 / 插件版本：独立于补丁版本，记录在 update-config.json，由发布脚本按改动范围维护
    let frameworkVersion = '1.0.0';
    let pluginVersion = '';
    try {
      const uc = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'update-config.json'), 'utf-8'));
      if (uc && uc.frameworkVersion) frameworkVersion = String(uc.frameworkVersion);
      if (uc && uc.pluginVersion) pluginVersion = String(uc.pluginVersion);
    } catch {}

    // 词库 / 消息 / 异常 / 趋势：仪表盘统计卡片与图表数据
    const dict = dictStats();
    const msgs = messageStats();
    // 面板账号统计：总数 + 今日新增（createdAt 落在北京时间今日）
    let usersTotal = 0;
    let usersToday = 0;
    try {
      const admins = (adminAuth ? adminAuth.getAdmins() : []) as any[];
      usersTotal = admins.length;
      const todayKey = new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10);
      for (const a of admins) {
        if (!a.createdAt) continue;
        const d = new Date(Number(a.createdAt) + 8 * 3600000).toISOString().slice(0, 10);
        if (d === todayKey) usersToday++;
      }
    } catch {}
    // 机器人状态分布（运行中 / 已停止 / 错误）
    const botStates = {
      running: botEntries.filter((b: any) => b && b.status === 'running').length,
      stopped: botEntries.filter((b: any) => b && b.status === 'stopped').length,
      error: botEntries.filter((b: any) => b && b.status === 'error').length,
    };
    // 当前登录用户的机器人额度（超主 5 / 其他有效用户 1，可在用户权限中单独覆盖）
    let quota = { used: 0, total: 0, role: '' };
    try {
      const u = (_req as any).adminUser as { username?: string; role?: string } | undefined;
      if (u && u.username) {
        const owned = botEntries.filter((b: any) => b && b.owner === u.username).length;
        const role = String(u.role || 'user');
        const cfgUser = adminAuth ? adminAuth.getUser(u.username) : undefined;
        const maxBots = resolveMaxBots(role, cfgUser?.permissions);
        quota = { used: owned, total: maxBots, role };
      }
    } catch {}

    res.json({
      // 版本优先取实际安装版本（package.json，随补丁更新），避免面板配置过时导致仪表盘显示旧版本/-
      version: pkgVer || cfgSafe('update.version') || '',
      frameworkVersion,
      pluginVersion,
      uptime: process.uptime(),          // 进程运行时长（秒）
      osUptime: os.uptime(),             // 系统运行时长（秒）
      host: { platform: os.platform(), arch: os.arch(), hostname: os.hostname(), release: os.release() },
      cpu: {
        percent: cpuPercent(),
        load1: os.loadavg()[0],
        load5: os.loadavg()[1],
        load15: os.loadavg()[2],
      },
      memory: {
        rss: Math.round(process.memoryUsage().rss / 1024 / 1024),
        heapTotal: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
        heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        osTotal: Math.round(totalMem / 1024 / 1024),
        osUsed: Math.round(usedMem / 1024 / 1024),
        osPercent: Math.round((usedMem / totalMem) * 100),
      },
      disk: disk ? { root: disk } : null,
      bots: { total: botsTotal, online: botsOnline },
      users: { total: usersTotal, today_new: usersToday },
      lexicons: { total: dict.files, entries: dict.entries },
      messages: { in: msgs.in, out: msgs.out, todayIn: msgs.todayIn, todayOut: msgs.todayOut, today: msgs.todayIn + msgs.todayOut },
      errorsToday: errorsToday(),
      trend14: eventTrend14(),
      botStates,
      quota,
      events24: eventTrend24(),
      recent,
      nodeVersion: process.version,
      pid: process.pid,
      pluginCount,
      pm2: pm2Status(),
      framework: {
        name: 'NapCatQQ',
        version: napcatVersion,
        integrated: true,
      },
      features: [
        '开关机控制', '主菜单路由', '娱乐中心', '实用工具',
        '签到系统', '群管理工具', '授权系统', '系统工具',
        '系统设置', 'DIC管理', '定时推送', '关键词回复',
        '问候插件', '词典回复', '按钮菜单', '整点报时',
        '新人欢迎', '退群提示', '全局模式切换',
      ],
    });
  });

  router.get('/hyperlinks', (_req: Request, res: Response) => {
    res.json({
      official: 'https://q.qq.com',
      docs: 'https://bot.q.qq.com/wiki',
      callback: 'https://bot.q.qq.com/wiki/develop/api-v2/server-inter/message/send-receive/msg-send.html',
    });
  });

  router.get('/help', (req: Request, res: Response) => {
    const host = req.get('host') || 'localhost:3000';
    const proto = (req.get('x-forwarded-proto') || req.protocol || 'https');
    const callbackUrl = `${proto}://${host}/qq/webhook`;
    res.json({
      title: 'QQ Bot Framework Help',
      sections: [
        {
          title: '快速开始',
          content: '1. 在 q.qq.com 注册机器人获取 AppID 和 AppSecret\n2. 在管理面板「我的机器人」页面点击「添加机器人」\n3. 填写 AppID、AppSecret 和 Intents\n4. 点击「启动」使机器人上线\n5. 在 QQ 开放平台配置回调地址',
        },
        {
          title: '插件开发文档',
          content: '插件以 zip 包形式打包上传。\n\n## 插件结构\n插件 zip 包内需包含:\n- `plugin.json` - 插件清单文件(必填)\n- `index.js` 或入口文件(必填)\n- `README.md` - 插件文档(可选)\n\n## plugin.json 格式\n{\n  "name": "my-plugin",\n  "version": "1.0.0",\n  "description": "我的插件",\n  "author": "作者名",\n  "main": "index.js",\n  "match": ["AT_MESSAGE_CREATE", "GROUP_MESSAGE_CREATE"]\n}\n\n## 入口文件示例 (index.js)\n`module.exports = function(ctx, next) {`\n`  if (ctx.event.content === "/hello") {`\n`    ctx.bot.messages.sendChannelMessage(ctx.event.channel_id, {`\n`      content: "Hello World!",`\n`      msg_id: ctx.event.id`\n`    });`\n`    return;`\n`  }`\n`  next();`\n`};`\n\n## 可用的 ctx 对象\nctx.bot - Bot 实例 (所有 API)\nctx.eventType - 事件类型\nctx.event - 事件数据\nctx.state - 跨中间件共享状态',
        },
        {
          title: '插件审核流程',
          content: '1. 普通用户上传插件后，状态为「待审核」\n2. 超级管理员在插件管理页面查看待审核插件\n3. 超级管理员可「批准」或「拒绝」插件\n4. 审核时可填写拒绝原因\n5. 只有「已批准」的插件会被加载执行\n6. 超级管理员上传的插件自动通过审核',
        },
        {
          title: '回调地址说明',
          content: `回调地址: ${callbackUrl}\n平台将在收到事件时 POST 到该地址。\n详细说明见官方文档: https://bot.q.qq.com/wiki`,
        },
        {
          title: '授权码说明',
          content: '授权码分为超级主人和主人角色。\n超级主人拥有全部权限（设置、用户管理、插件审核、机器人管理等）。\n主人拥有基本操作权限（添加管理自己机器人等），权限可由超级管理员配置。\n授权码可设置过期时间，过期后自动注销。',
        },
      ],
    });
  });

  // 功能开关：读取（登录用户） / 设置（超级主人），与插件共用 config 表同一状态
  router.get('/switches', (_req: Request, res: Response) => {
    res.json({ switches: getSwitchStates() });
  });

  router.put('/switches', requireSuperMaster, (req: Request, res: Response) => {
    const { key, enabled } = req.body || {};
    if (!key || typeof enabled !== 'boolean') { res.json({ ok: false, error: '需要 key 与布尔 enabled' }); return; }
    const s = setSwitchState(String(key), enabled);
    if (!s) { res.json({ ok: false, error: '未知开关：' + key }); return; }
    res.json({ ok: true, switch: s });
  });

  // 定时任务：读取（登录用户） / 管理（超级主人）
  router.get('/schedule-tasks', (_req: Request, res: Response) => {
    res.json({ tasks: listScheduleTasks() });
  });

  router.post('/schedule-tasks', requireSuperMaster, (req: Request, res: Response) => {
    const r = createScheduleTask(req.body || {});
    if (!r.ok) { res.json({ ok: false, error: r.error }); return; }
    res.json({ ok: true, task: r.task });
  });

  router.put('/schedule-tasks', requireSuperMaster, (req: Request, res: Response) => {
    const r = updateScheduleTask(req.body || {});
    if (!r.ok) { res.json({ ok: false, error: r.error }); return; }
    res.json({ ok: true, task: r.task });
  });

  router.delete('/schedule-tasks', requireSuperMaster, (req: Request, res: Response) => {
    const id = String(req.query.id || '');
    if (!id) { res.json({ ok: false, error: '缺少 id' }); return; }
    const r = deleteScheduleTask(id);
    res.json({ ok: r.ok });
  });

  router.post('/schedule-tasks/toggle', requireSuperMaster, (req: Request, res: Response) => {    const id = String((req.body || {}).id || '');
    if (!id) { res.json({ ok: false, error: '缺少 id' }); return; }
    const r = toggleScheduleTask(id);
    if (!r.ok) { res.json({ ok: false, error: r.error }); return; }
    res.json({ ok: true, task: r.task });
  });

  // 机器人互动用户列表（user_mappings：头像/QQ/昵称/OpenID）
  router.get('/users', (_req: Request, res: Response) => {
    try {
      const db = getDb();
      const rows = db.prepare(
        "SELECT openid, qq_number, nickname, bot_id, last_updated FROM user_mappings ORDER BY last_updated DESC LIMIT 1000"
      ).all() as any[];
      res.json({ users: rows });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 反馈提交列表（插件"反馈"命令提交，面板只读）；超主可传 bot_id 过滤
  router.get('/feedbacks', (_req: Request, res: Response) => {
    try {
      const db = getDb();
      const botId = (_req.query.bot_id as string) || '';
      const rows = botId
        ? db.prepare("SELECT * FROM feedbacks WHERE bot_id = ? ORDER BY created_at DESC LIMIT 500").all(botId)
        : db.prepare("SELECT * FROM feedbacks ORDER BY created_at DESC LIMIT 500").all();
      res.json({ feedbacks: rows });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 反馈回复：发私聊给反馈提交者 + 更新状态（面板直接回复）
  router.post('/feedbacks/:id/reply', requireSuperMaster, async (req: Request, res: Response) => {
    try {
      const id = String(req.params.id || '');
      const reply = String((req.body || {}).reply || '').trim();
      if (!id || !reply) { res.json({ ok: false, error: '缺少 id 或回复内容' }); return; }
      const db = getDb();
      const f = db.prepare('SELECT * FROM feedbacks WHERE id = ?').get(id) as any;
      if (!f) { res.json({ ok: false, error: '反馈不存在：' + id }); return; }
      const botId = String(f.bot_id || '');
      let bot: any;
      try { bot = botId ? getBotInstance(botId) || getBot() : getBot(); } catch { bot = null; }
      if (!bot) { res.json({ ok: false, error: '机器人未初始化，无法发送回复' }); return; }
      const openid = String(f.user_openid || '');
      if (!openid) { res.json({ ok: false, error: '反馈提交者无 OpenID，无法私聊回复' }); return; }
      const sent = await bot.sendPrivateMessage(openid, '📩 反馈回复\n━━━━━━━━━━━━━━\n你的反馈：' + String(f.content || '') + '\n━━━━━━━━━━━━━━\n机器人的回复：\n' + reply + '\n━━━━━━━━━━━━━━\nPHP · QQ机器人平台');
      if (!sent) { res.json({ ok: false, error: '机器人私聊发送失败（OpenID: ' + openid.slice(0, 12) + '...）' }); return; }
      db.prepare("UPDATE feedbacks SET reply = ?, status = 'replied', replied_at = datetime('now', 'localtime') WHERE id = ?").run(reply, id);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  // 反馈状态更新（pending → done）
  router.put('/feedbacks/:id', requireSuperMaster, (req: Request, res: Response) => {
    try {
      const id = String(req.params.id || '');
      const status = String((req.body || {}).status || 'done');
      const db = getDb();
      db.prepare('UPDATE feedbacks SET status = ? WHERE id = ?').run(status, id);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 删除反馈
  router.delete('/feedbacks/:id', requireSuperMaster, (req: Request, res: Response) => {
    try {
      const id = String(req.params.id || '');
      const db = getDb();
      db.prepare('DELETE FROM feedbacks WHERE id = ?').run(id);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 群列表（用户管理/成员同步：群OpenID、群名、群号、群头像、成员数）；超主可传 bot_id 过滤
  router.get('/groups', (_req: Request, res: Response) => {
    try {
      const db = getDb();
      const botId = (_req.query.bot_id as string) || '';
      const rows = (botId
        ? db.prepare('SELECT * FROM groups WHERE bot_id = ? ORDER BY last_active DESC LIMIT 1000').all(botId)
        : db.prepare('SELECT * FROM groups ORDER BY last_active DESC LIMIT 1000').all()) as any[];
      for (const g of rows) {
        // member_count 为群真实人数（群信息接口同步或后台手改），active_members 为本地已收录成员数。
        // 不再用本地收录数覆盖真实人数，避免「群人数与实际不符」。
        g.member_count = Number(g.member_count) || 0;
        try {
          const c = db.prepare('SELECT COUNT(*) AS c FROM group_members WHERE group_id = ?').get(g.id) as any;
          g.active_members = c?.c || 0;
        } catch { g.active_members = 0; }
      }
      res.json({ groups: rows });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 修改群：群名 / 群号（群号变更自动生成群头像）
  router.put('/groups/:id', requireSuperMaster, (req: Request, res: Response) => {
    try {
      const id = String(req.params.id || '');
      const body = req.body || {};
      const db = getDb();
      const g = db.prepare('SELECT * FROM groups WHERE id = ?').get(id) as any;
      if (!g) { res.json({ ok: false, error: '群不存在：' + id }); return; }
      const next: any = { name: g.name, group_number: g.group_number, avatar: g.avatar, member_count: Number(g.member_count) || 0, member_count_manual: Number(g.member_count_manual) || 0 };
      if (body.name !== undefined) next.name = String(body.name).trim();
      if (body.group_number !== undefined) {
        next.group_number = String(body.group_number).trim();
        if (/^\d{6,15}$/.test(next.group_number)) next.avatar = `https://p.qlogo.cn/gh/${next.group_number}/${next.group_number}/0`;
      }
      if (body.avatar !== undefined && body.avatar !== '') next.avatar = String(body.avatar).trim();
      // 群人数可编辑：后台填写后锁定，群信息接口不再自动覆盖
      if (body.member_count !== undefined && body.member_count !== null && String(body.member_count) !== '') {
        const mc = parseInt(String(body.member_count), 10);
        if (isNaN(mc) || mc < 0 || mc > 100000) { res.json({ ok: false, error: '群人数应为 0-100000 的整数' }); return; }
        next.member_count = mc;
        next.member_count_manual = 1;
      }
      db.prepare('UPDATE groups SET name = ?, group_number = ?, avatar = ?, member_count = ?, member_count_manual = ? WHERE id = ?')
        .run(next.name, next.group_number, next.avatar, next.member_count, next.member_count_manual, id);
      res.json({ ok: true, group: { ...next, id } });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 批量删除群（连带删除群成员记录）
  router.post('/groups/batch-delete', requireSuperMaster, (req: Request, res: Response) => {
    try {
      const ids: any[] = Array.isArray((req.body || {}).ids) ? req.body.ids : [];
      if (!ids.length) { res.json({ ok: false, error: 'ids required' }); return; }
      const db = getDb();
      let deleted = 0;
      for (const raw of ids) {
        const gid = String(raw || '').trim();
        if (!gid) continue;
        db.prepare('DELETE FROM groups WHERE id = ?').run(gid);
        db.prepare('DELETE FROM group_members WHERE group_id = ?').run(gid);
        deleted++;
      }
      res.json({ ok: true, deleted });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 删除群（连带删除该群群成员记录）
  router.delete('/groups/:id', requireSuperMaster, (req: Request, res: Response) => {
    try {
      const id = String(req.params.id || '');
      const db = getDb();
      db.prepare('DELETE FROM groups WHERE id = ?').run(id);
      db.prepare('DELETE FROM group_members WHERE group_id = ?').run(id);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 群+成员合并数据（用户管理页：按群组织，含群头像/群号/群OpenID/群名 与成员 QQ/昵称/授权码/权限）
  router.get('/user-groups', (_req: Request, res: Response) => {
    try {
      const db = getDb();
      const groups = db.prepare('SELECT * FROM groups ORDER BY last_active DESC LIMIT 1000').all() as any[];
      const out: any[] = [];
      for (const g of groups) {
        const members = db.prepare('SELECT member_openid, qq_id, nickname, bot_id, first_seen, last_seen FROM group_members WHERE group_id = ? ORDER BY last_seen DESC').all(g.id) as any[];
        const arr = members.map((m: any) => {
          let qq = (m.qq_id && /^\d{5,12}$/.test(m.qq_id)) ? m.qq_id : '';
          let nick = m.nickname || '';
          let umBotId = m.bot_id || '';
          try {
            const um = db.prepare('SELECT qq_number, nickname, bot_id FROM user_mappings WHERE openid = ?').get(m.member_openid) as any;
            if (um) {
              if (!qq) qq = um.qq_number || '';
              if (!nick) nick = um.nickname || '';
              if (!umBotId) umBotId = um.bot_id || '';
            }
          } catch {}
          return {
            openid: m.member_openid,
            qq_number: qq,
            nickname: nick,
            source: qq ? (m.qq_id ? 'mapped' : 'interact') : 'none',
            bot_id: umBotId,
          };
        });
        out.push({ ...g, members: arr });
      }
      let orphanUsers: any[] = [];
      try {
        orphanUsers = db.prepare(
          "SELECT um.openid, um.qq_number, um.nickname, um.bot_id FROM user_mappings um WHERE NOT EXISTS (SELECT 1 FROM group_members gm WHERE gm.member_openid = um.openid) ORDER BY um.last_updated DESC LIMIT 200"
        ).all() as any[];
      } catch {}
      res.json({ groups: out, orphanUsers });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // 服务端接收端：接收端信息（部署根/当前版本/AI 端最新配置），供前端「服务端接收」区块展示
  router.get('/update-receive/info', requireSuperMaster, async (_req: Request, res: Response) => {
    try {
      const root = receiverRoot();
      const dir = updateRecDir();
      let currentVersion = '';
      if (fs.existsSync(path.join(dir, '状态.json'))) {
        const s = JSON.parse(fs.readFileSync(path.join(dir, '状态.json'), 'utf-8') || '{}');
        currentVersion = String(s.version || '');
      }
      const ai = await fetchAiConfig();
      res.json({
        ok: true,
        rootDir: root,
        panelDir: process.cwd(),
        currentVersion,
        recordFile: path.join(dir, '记录.json'),
        aiUrls: aiConfigUrls(),
        ai,
      });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  const receiverUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 400 * 1024 * 1024 } });
  // 服务端接收：一键接收并部署更新包
  //  - multipart file=本地上传 zip
  //  - body.url=手动指定远程 zip 直链（单源）
  //  - body.kind=patch|full（无 url/file 时）：从云端 update-config 自动取全部候选源，
  //    GitHub Release 主源失败自动切换加速镜像/备用源，直到下载成功
  // 与群内「更新系统」插件串联：同一记录文件 + 当前版本 + 覆盖式解压 + pm2 restart qqbot
  router.post('/update-receive', requireSuperMaster, receiverUpload.single('file'), async (req: Request, res: Response) => {
    try {
      const file = (req as any).file as { buffer: Buffer; originalname: string } | undefined;
      const bodyUrl = String((req.body && req.body.url) || '').trim();
      if (file && !bodyUrl) {
        const result = await receiveUpdatePackage({ zipBuffer: file.buffer, zipName: file.originalname || 'update.zip' });
        res.json(result);
        return;
      }
      if (bodyUrl) {
        if (!/^https?:\/\//i.test(bodyUrl)) {
          res.json({ ok: false, step: '参数', error: '下载地址需为 http/https 链接' });
          return;
        }
        const zipName = decodeURIComponent(bodyUrl.split('?')[0].split('/').pop() || 'update.zip');
        const ai = await fetchAiConfig();
        const result = await receiveUpdatePackage({ zipUrl: bodyUrl, zipName, changeLog: ai && ai.ok ? ai.changeLog : '' });
        res.json(result);
        return;
      }
      const kindRaw = String((req.body && req.body.kind) || '').toLowerCase();
      const isFull = kindRaw === 'full' || /full|全量/.test(kindRaw);
      if (kindRaw) {
        const ai = await fetchAiConfig();
        if (!ai || !ai.ok || !ai.sources.length) {
          const errs = (ai && ai.errors && ai.errors.length ? ai.errors : []).join('；');
          res.json({ ok: false, step: '配置', error: `无法拉取云端更新配置${errs ? '（' + errs + '）' : ''}。请在「更新系统配置」填好下载地址或检查网络。` });
          return;
        }
        const urls = ai.sources.map((s: any) => (isFull ? s.fullUrl : s.patchUrl)).filter(Boolean);
        if (urls.length === 0) {
          res.json({ ok: false, step: '配置', error: `云端更新配置中未找到${isFull ? '全量包' : '补丁包'}下载地址` });
          return;
        }
        const result = await receiveUpdatePackage({ zipUrls: urls, zipName: '', changeLog: ai.changeLog });
        res.json(result);
        return;
      }
      res.json({ ok: false, step: '参数', error: '请提供 zip 文件、下载地址（url）或更新类型（kind=patch/full）' });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  // ================= GitHub 云端广播（broadcast/broadcast.json，多源拉取） =================
  // 列表：拉取云端目录（含单任务示例与解析错误），供面板展示/群内菜单调用
  router.get('/broadcast/list', requireSuperMaster, async (_req: Request, res: Response) => {
    try {
      const cat = await loadBroadcastCatalog(true);
      const tasks = cat.tasks.map((t) => ({
        id: t.id,
        name: t.name,
        enabled: t.enabled,
        send: t.send,
        target: t.target,
        groupId: t.groupId || '',
        groups: t.groups || [],
        schedule: t.schedule || null,
        hasContent: !!String(t.content || '').trim(),
        hasApi: !!(t.api && t.api.url),
      }));
      res.json({ ok: cat.ok, source: cat.sourceUrl || '', urls: BROADCAST_URLS, errors: cat.errors, tasks });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  // 立即广播（试播）：taskId 必填；target=all/one/group/this/list；send=text/image 覆盖任务默认；dryRun=true 只统计不发送。
  // 采用异步任务：立即返回 jobId，面板轮询 /broadcast/job/:jobId 拿逐群发送结果，避免大批量广播撑爆网关导致 Failed to fetch。
  router.post('/broadcast/send', requireSuperMaster, async (req: Request, res: Response) => {
    try {
      const taskId = String((req.body || {}).taskId || '').trim();
      if (!taskId) { res.json({ ok: false, error: '缺少 taskId' }); return; }
      const t = await loadBroadcastTaskById(taskId);
      if (!t) {
        res.json({ ok: false, error: '云端广播任务不存在或目录不可用: ' + taskId });
        return;
      }
      const target = String((req.body || {}).target || 'default');
      const groupId = String((req.body || {}).groupId || '');
      const dryRun = (req.body || {}).dryRun === true;
      const send = String((req.body || {}).send || 'default');
      const jobId = 'cb_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
      broadcastJobStore.set(jobId, { status: 'running', jobId, taskId, taskName: t.name, started: Date.now(), updated: Date.now() });
      void (async () => {
        try {
          const result = await runBroadcastNow(t, { target, groupId, dryRun, send: send === 'default' ? undefined : send });
          broadcastJobStore.set(jobId, { status: 'done', jobId, updated: Date.now(), finished: Date.now(), ...result });
        } catch (e: any) {
          broadcastJobStore.set(jobId, {
            status: 'error', jobId, updated: Date.now(), finished: Date.now(),
            ok: false, taskId, taskName: t.name, send: '', text: '', target: [], total: 0, sent: 0, failed: [],
            error: (e && e.message) ? e.message : String(e),
          });
        }
      })();
      res.status(202).json({ ok: true, started: true, jobId, taskId, message: dryRun ? '试播任务已提交，稍候查结果' : '广播任务已提交，逐群后台发送中（可稍后点「立即广播」旁的刷新查看结果）' });
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  // 广播任务进度/结果查询
  router.get('/broadcast/job/:jobId', requireSuperMaster, async (req: Request, res: Response) => {
    const job = broadcastJobStore.get(String(req.params.jobId || ''));
    if (!job) { res.json({ ok: false, error: '任务不存在或已过期' }); return; }
    res.json(job);
  });

  // 同步定时：把云端带 schedule 的任务登记/更新成本机定时任务（schedule-runner 到点执行）
  router.post('/broadcast/sync', requireSuperMaster, async (_req: Request, res: Response) => {
    try {
      const r = await syncBroadcastSchedules();
      res.json(r);
    } catch (e: any) {
      res.status(500).json({ ok: false, error: e.message });
    }
  });

  return router;
}