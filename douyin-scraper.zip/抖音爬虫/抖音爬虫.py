# plugin/xxx/xxx.py
import os
import sys
import importlib.util
from termcolor import colored




"----------------------------这里的不要动！！！！！！！！！！！----------------------------"
qxlog=None
# 通用动态加载外部py文件函数
def load_external_mod(filename):
    # 判断是否打包成exe，区分路径
    if getattr(sys, "frozen", False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    mod_path = os.path.join(base_dir, filename)
    mod_name = os.path.splitext(filename)[0]
    spec = importlib.util.spec_from_file_location(mod_name, mod_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod
def qxlog_print(color,text):#日志输出函数
    qxlog.qxlog_print(color,f"[插件]{text}")
"""
以下为日志输出的颜色代码：
输出日志请调用qxlog_print()函数
并且传入两个参数 (颜色代码,输出内容)
绿色 -16711936
红色 -65536
白色 -1
黄色 -256



日志输出规范
如果调用了API请求请在输出内容前加上
[API请求]
用作标记消息统计请求数量
"""

try:
    qxlog= load_external_mod("qxlog_print.py")
    print(colored(f"qxlog_print(日志输出模块)启动成功", "green"))
    qxlog_print(-16711936,f"qxlog_print(日志输出模块)启动成功")
except Exception as e:
    print(colored(f"qxlog_print(日志输出模块)启动失败{e}", "red"))
    qxlog_print(-65536,f"qxlog_print(日志输出模块)启动失败{e}")


#引入所需的库
#终端安装所需库命令
#pip install requests
#pip install bs4
#requests库用于发送网络请求
import requests
#引入BeautifulSoup库用于解析HTML
from bs4 import BeautifulSoup
#引入unquote函数用于解码URL编码
from urllib.parse import unquote
#引入json库用于处理JSON数据
import json
#引入hashlib用于计算文件MD5/SHA1
import hashlib
#引入time用于生成临时文件名
import time
#引入threading用于后台异步下载
import threading
#引入Path用于文件路径操作
from pathlib import Path
#引入pprint库用于美化输出--分析数据时用（未调用）
from pprint import pprint
def douyin(url):
    headers={
        "referer":"https://www.douyin.com/jingxuan?modal_id=7521394919349439795"
        ,"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
        ,"cookie":"a0ab33eaf22428957f475f626977b173f94957c7849b046cc7f9250ce13f2ce87b5cf546870869ae0ba7b0c65c8a8982266f9cb4567ac995bacce5949292f34d7b89310a65e3ddab2ca2ddd5cb54f2c5fdada1cce7b42836d4e40aaaf6a3c9cc25bf478fd7626988eee48b7c209bfbe0; fpk1=U2FsdGVkX1+TdJauonE7to4QR1bWZt5oGrFH4xBPMbn4l0dVNZjXV3Y3PGdshD+eWZCR3EhkUuQW61MkdRshOw==; fpk2=99d149899c4f2f3d79df1f8e73f539ef; UIFID=a0ab33eaf22428957f475f626977b173f94957c7849b046cc7f9250ce13f2ce87b5cf546870869ae0ba7b0c65c8a8982266f9cb4567ac995bacce5949292f34d653a4fa0beb4ac40f3b618ff078a6a6cd52cd06450277cbe5732bb0a0d2a9246584d5edfe9b2254db3d86667a4da54fd13110fd8b228e310d73c3ae060d0092d2487603373c528816eec6a0abca4969a4a0121d302b8dca39d0c75cb4c7fded2c8382f8047223ba54dc604e3620734faa60b1fad6b6bd3c4f162c6a26f76cd63; bd_ticket_guard_client_web_domain=2; enter_pc_once=1; xgplayer_user_id=523352546254; is_staff_user=false; _bd_ticket_crypt_doamin=2; __security_mc_1_s_sdk_cert_key=b8708bf2-4af2-8e08; __security_server_data_status=1; passport_assist_user=CktkGX_VHbnys9DsH8Fc-UMnmqEewrowBckIAZebxz8azpensivt52k0kWBRs6uI-km52I5aXQEleJbpgQpovOmZNFnJY_bW8ElfPAYaSgo8AAAAAAAAAAAAAE8YFVV1RfKq4U4EOiDf-D4f5792vPAdFPkcWyzbv4iCvapXkJYvgEl5MC2iWHBdc6ZtELLS8w0Yia_WVCABIgEDZsLmRg%3D%3D; n_mh=9-mIeuD4wZnlYrrOvfzG3MuT6aQmCUtmr8FxV8Kl8xY; uid_tt=b7ca59251ad3c5e4f65ba6c3ae428132; uid_tt_ss=b7ca59251ad3c5e4f65ba6c3ae428132; sid_tt=7f4ed0794e3512e4b14aaf39a86fc6d5; sessionid=7f4ed0794e3512e4b14aaf39a86fc6d5; sessionid_ss=7f4ed0794e3512e4b14aaf39a86fc6d5; _bd_ticket_crypt_cookie=0b792ed805fd12114cbcd475abbe0653; __security_mc_1_s_sdk_sign_data_key_web_protect=4cfa32d6-4220-aeb0; passport_mfa_token=CjZFv%2B3p4vr4%2BAnLfUqzn8J4GElOwc4xIj%2F1hYdiLQ9HBL91n7Fndlr6EYfSaJO0Y3ckHMSfYjEaSgo8AAAAAAAAAAAAAE8Yl0WasOsjnasxrAld0HaBAHZLbQ%2BZ7WJzcub5FfClzwGo3hELz79rD4eorT1fUSIEEOnS8w0Y9rHRbCACIgEDG5Vdgg%3D%3D; d_ticket=4a895bd5feedd05dfbce38dc82ed1a8c89443; SelfTabRedDotControl=%5B%5D; s_v_web_id=verify_mcx6x23q_XK1FHvo6_7Id0_4V58_BeyR_8bCyGDsgOc2T; __security_mc_1_s_sdk_crypt_sdk=99487574-406d-a786; passport_csrf_token=ef279efe0a6c10d614222443e426deea; passport_csrf_token_default=ef279efe0a6c10d614222443e426deea; session_tlb_tag=sttt%7C4%7Cf07QeU41EuSxSq85qG_G1f________-g0lgIGwkThflvTbYLDhy1qk3eLp2aNOsjiOpViqDi2qA%3D; xgplayer_device_id=11583233877; dy_swidth=1536; dy_sheight=864; stream_recommend_feed_params=%22%7B%5C%22cookie_enabled%5C%22%3Atrue%2C%5C%22screen_width%5C%22%3A1536%2C%5C%22screen_height%5C%22%3A864%2C%5C%22browser_online%5C%22%3Atrue%2C%5C%22cpu_core_num%5C%22%3A12%2C%5C%22device_memory%5C%22%3A8%2C%5C%22downlink%5C%22%3A10%2C%5C%22effective_type%5C%22%3A%5C%224g%5C%22%2C%5C%22round_trip_time%5C%22%3A50%7D%22; volume_info=%7B%22isUserMute%22%3Afalse%2C%22isMute%22%3Atrue%2C%22volume%22%3A0.863%7D; sid_guard=7f4ed0794e3512e4b14aaf39a86fc6d5%7C1754488117%7C5184000%7CSun%2C+05-Oct-2025+13%3A48%3A37+GMT; sid_ucp_v1=1.0.0-KGVjZmY0ZDM0ZGY1NWFjN2RkMzM0NjEyYjY3NTMxN2NlZTFmNWM0NTMKIAjZ6fDR1s1rELW6zcQGGNoWIAwwjMfavgY4B0D0B0gEGgJobCIgN2Y0ZWQwNzk0ZTM1MTJlNGIxNGFhZjM5YTg2ZmM2ZDU; ssid_ucp_v1=1.0.0-KGVjZmY0ZDM0ZGY1NWFjN2RkMzM0NjEyYjY3NTMxN2NlZTFmNWM0NTMKIAjZ6fDR1s1rELW6zcQGGNoWIAwwjMfavgY4B0D0B0gEGgJobCIgN2Y0ZWQwNzk0ZTM1MTJlNGIxNGFhZjM5YTg2ZmM2ZDU; publish_badge_show_info=%221%2C0%2C0%2C1754488110488%22; WallpaperGuide=%7B%22showTime%22%3A1754488178958%2C%22closeTime%22%3A0%2C%22showCount%22%3A1%2C%22cursor1%22%3A10%2C%22cursor2%22%3A2%7D; __ac_nonce=068941c19004996bdf11d; __ac_signature=_02B4Z6wo00f01EOXs8AAAIDDLmeGszjM9CRDt7dAAHh5b8; douyin.com; device_web_cpu_core=12; device_web_memory_size=8; architecture=amd64; strategyABtestKey=%221754536991.376%22; download_guide=%223%2F20250807%2F0%22; passport_fe_beating_status=true; biz_trace_id=9d483197; xg_device_score=7.802204888412783; live_use_vvc=%22false%22; webcast_leading_last_show_time=1754537774902; webcast_leading_total_show_times=1; stream_player_status_params=%22%7B%5C%22is_auto_play%5C%22%3A0%2C%5C%22is_full_screen%5C%22%3A0%2C%5C%22is_full_webscreen%5C%22%3A0%2C%5C%22is_mute%5C%22%3A1%2C%5C%22is_speed%5C%22%3A1%2C%5C%22is_visible%5C%22%3A0%7D%22; bd_ticket_guard_client_data=eyJiZC10aWNrZXQtZ3VhcmQtdmVyc2lvbiI6MiwiYmQtdGlja2V0LWd1YXJkLWl0ZXJhdGlvbi12ZXJzaW9uIjoxLCJiZC10aWNrZXQtZ3VhcmQtcmVlLXB1YmxpYy1rZXkiOiJCRGcvQjU0RzJBQ1lxdDZzdFdEdmhqU1RwUlNLbGFpK3JlSHZzUjRBODNyR1crSzZGUTNZYnhEbHNpM3BwWUNXTG15TXo4S2szYnluL0tXK3JYam9GVE09IiwiYmQtdGlja2V0LWd1YXJkLXdlYi12ZXJzaW9uIjoyfQ%3D%3D; odin_tt=e048ffcb4f57ea34172353e0977d80bc7fd85172e283211efba0e23714f38aabbe2fc72a4b18873b6962830346bb7812ed913f60e5edea1e746e473ba8dfccae; ttwid=1%7CWimmrXR6a22oV27zC8EW6E74LZyaIJyX4goNooWEkos%7C1754537933%7Cd1a04c7004ece39f7e93f76ed878e55e7f79d69bbf1edfac86dcf05e5ad9041a; playRecommendGuideTagCount=3; totalRecommendGuideTagCount=3; IsDouyinActive=true; home_can_add_dy_2_desktop=%220%22"
    }#设置请求头部信息--模拟浏览器访问

    #发送请求获取网页内容
    html=requests.get(url,headers=headers).text
    #将返回内容街西城html
    html=BeautifulSoup(html,"html.parser")#解析HTML内容
    #查找RENDER_DATA脚本标签--过滤html中无用部分
    info = html.findAll("script", id="RENDER_DATA", type="application/json")[0]
    #解码RENDER_DATA脚本标签内容
    json_str = unquote(info.string)
    #将解码后的字符串转换为JSON格式
    json_data =json .loads(json_str)
    #取出视频url
    video_url = json_data['app']['videoDetail']['video']['bitRateList'][0]['playAddr'][0]['src']
    #获取视频标题
    video_title=json_data['app']['videoDetail']['desc']

    print("视频下载链接：", video_url)
    return video_title,video_url


# ========== 视频下载与分片上传 ==========
PLUGIN_DIR = Path(__file__).parent
TEMP_DIR = PLUGIN_DIR / "temp"
TEMP_DIR.mkdir(exist_ok=True, parents=True)

def download_video(video_url, save_path):
    """下载抖音视频到本地"""
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
        "Referer": "https://www.douyin.com/"
    }
    with requests.get(video_url, headers=headers, stream=True, timeout=(30, 120)) as resp:
        resp.raise_for_status()
        with open(save_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
    return save_path

def calc_file_hashes(file_path):
    """计算文件的MD5、SHA1、前10002432字节(约10MB)的MD5"""
    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    md5_10m = hashlib.md5()
    first_10m_bytes = 10002432
    read_10m = 0
    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            md5.update(chunk)
            sha1.update(chunk)
            if read_10m < first_10m_bytes:
                to_read = min(len(chunk), first_10m_bytes - read_10m)
                md5_10m.update(chunk[:to_read])
                read_10m += to_read
    return md5.hexdigest(), sha1.hexdigest(), md5_10m.hexdigest()

def upload_video_by_parts(access_token, group_openid, file_path, file_name):
    """QQ群视频分片上传完整流程，返回file_info"""
    api_base = "https://api.sgroup.qq.com"
    headers = {"Authorization": f"QQBot {access_token}"}
    file_size = os.path.getsize(file_path)
    qxlog_print(-1, f"[API请求]分片上传开始 文件大小:{file_size}字节 文件名:{file_name}")
    md5_val, sha1_val, md5_10m_val = calc_file_hashes(file_path)

    # 1. upload_prepare 预上传，获取upload_id和分片预签名URL
    prepare_data = {
        "file_type": 2,
        "file_size": str(file_size),
        "file_name": file_name,
        "md5": md5_val,
        "sha1": sha1_val,
        "md5_10m": md5_10m_val
    }
    prepare_resp = requests.post(
        f"{api_base}/v2/groups/{group_openid}/upload_prepare",
        json=prepare_data,
        headers=headers,
        timeout=60
    ).json()
    qxlog_print(-1, f"[API请求]upload_prepare返回:{json.dumps(prepare_resp,ensure_ascii=False)[:300]}")
    if "upload_id" not in prepare_resp:
        qxlog_print(-65536, f"upload_prepare失败 无upload_id:{json.dumps(prepare_resp,ensure_ascii=False)}")
        return None
    upload_id = prepare_resp["upload_id"]
    parts = prepare_resp["parts"]
    qxlog_print(-1, f"upload_id:{upload_id} 分片数:{len(parts)}")

    # 2. 逐片PUT到预签名URL + upload_part_finish通知服务端
    with open(file_path, "rb") as f:
        for part in parts:
            index = part["index"]
            presigned_url = part["presigned_url"]
            part_block_size = int(part["block_size"])
            chunk_data = f.read(part_block_size)
            # PUT分片数据到预签名URL
            with requests.put(presigned_url, data=chunk_data, timeout=(30, 300)) as put_resp:
                if put_resp.status_code >= 400:
                    qxlog_print(-65536, f"分片{index}PUT失败 状态码:{put_resp.status_code} 响应:{put_resp.text[:200]}")
                    return None
                # 读取响应体确保连接释放回池
                _ = put_resp.content
            # 计算该分片MD5
            part_md5 = hashlib.md5(chunk_data).hexdigest()
            # upload_part_finish 通知服务端该分片完成
            finish_data = {
                "upload_id": upload_id,
                "part_index": index,
                "block_size": str(len(chunk_data)),
                "md5": part_md5
            }
            finish_resp = requests.post(
                f"{api_base}/v2/groups/{group_openid}/upload_part_finish",
                json=finish_data,
                headers=headers,
                timeout=60
            ).json()
            if finish_resp and "code" in finish_resp and finish_resp["code"] not in (0, None):
                qxlog_print(-65536, f"分片{index}finish失败:{json.dumps(finish_resp,ensure_ascii=False)}")
                return None
            qxlog_print(-1, f"分片{index}上传完成 大小:{len(chunk_data)}字节")

    # 3. 携带upload_id调用files接口完成合并，返回file_info
    merge_data = {
        "file_type": 2,
        "srv_send_msg": False,
        "file_name": file_name,
        "upload_id": upload_id
    }
    merge_resp = requests.post(
        f"{api_base}/v2/groups/{group_openid}/files",
        json=merge_data,
        headers=headers,
        timeout=60
    ).json()
    qxlog_print(-1, f"[API请求]files合并返回:{json.dumps(merge_resp,ensure_ascii=False)[:300]}")
    return merge_resp.get("file_info")

def send_douyin_video(access_token, group_openid, video_title, video_url, msg_id,user_id):
    """下载抖音视频到本地 → 分片上传 → 返回发送消息的resp_data（同步等待，一次返回）"""
    temp_file = TEMP_DIR / f"douyin_{int(time.time()*1000)}.mp4"
    try:
        # 下载视频到本地
        download_video(video_url, temp_file)
        # 分片上传获取file_info
        safe_name = video_title[:30].replace("/", "_").replace("\\", "_") + ".mp4"
        file_info = upload_video_by_parts(access_token, group_openid, temp_file, safe_name)
        if file_info:
            return [{
                "msg_type": 7,
                "media": {"file_info": file_info},
                "msg_id": msg_id
            },
            {
                "msg_type": 2,
                "markdown":{"content":f"""<qqbot-at-user id="{user_id}" />爬虫结果⬆️\n{video_title}"""}
            }]
        else:
            return {
                "msg_type": 0,
                "content": "文件上传失败（可能因为文件过大或其他原因）",
                "msg_id": msg_id
            }
    except Exception as e:
        return {
            "msg_type": 0,
            "content": f"处理失败：{e}",
            "msg_id": msg_id
        }
    finally:
        # 删除本地临时视频文件
        if temp_file.exists():
            try:
                temp_file.unlink()
            except:
                pass





class Comm:
    def __init__(self):
        "----------------------------以下可进行修改(字符串中内容)----------------------------"
        self.name = ""#插件名
        self.creator=""#插件作者



    "----------------------------以下函数为主要通讯函数 开发插件功能----------------------------"
    def handle_c2c_message(self,json_data):# 单聊消息事件
        """ """

    def handle_friend_add(self,json_data):# 用户添加好友
        """ """

    def handle_friend_delete(self,json_data):# 用户删除好友
        """ """

    def handle_c2c_push_enable(self,json_data):# 单聊消息接收开启
        """ """

    def handle_c2c_push_disable(self,json_data):# 单聊消息接收关闭
        """ """

    def handle_group_at_message(self,json_data):# 群@机器人消息
        access_token=json_data['access_token']
        group_openid=json_data['group_openid']
        user_id=json_data['author']['id']
        content=json_data['content']
        msg_id=json_data['id']
        if content==" #抖音爬虫":
            resp_data={
                "msg_type":2,
                "markdown":{
                    "content":"""# 抖音爬虫\n <qqbot-cmd-input text="抖音爬虫链接||" show="点击填写链接" reference="false" />"""
                },
                "msg_id":msg_id
            }
            return resp_data
        if "抖音爬虫链接||" in content:
            import re
            after_mark = content.split("||",1)[1]
            match = re.search(r"(https?://[^\s]+)", after_mark)
            if not match:
                resp_data = {
                    "msg_type":2,
                    "markdown":{"content":"# 错误❌\n未识别抖音链接"},
                    "msg_id":msg_id
                }
                return resp_data
            url = match.group(1)
            douyin_=douyin(url)
            video_title=douyin_[0]
            video_url=douyin_[1]
            resp_data = send_douyin_video(access_token, group_openid, video_title, video_url, msg_id,user_id)
            return resp_data

    def handle_group_message(self,json_data):# 群消息（全量模式）
        access_token=json_data['access_token']
        group_openid=json_data['group_openid']
        user_id=json_data['author']['id']
        content=json_data['content']
        msg_id=json_data['id']
        if content=="#抖音爬虫":
            resp_data={
                "msg_type":2,
                "markdown":{
                    "content":"""# 抖音爬虫\n <qqbot-cmd-input text="抖音爬虫链接||" show="点击填写链接" reference="false" />"""
                },
                "msg_id":msg_id
            }
            return resp_data
        if "抖音爬虫链接||" in content:
            import re
            after_mark = content.split("||",1)[1]
            match = re.search(r"(https?://[^\s]+)", after_mark)
            if not match:
                resp_data = {
                    "msg_type":2,
                    "markdown":{"content":"# 错误❌\n未识别抖音链接"},
                    "msg_id":msg_id
                }
                return resp_data
            url = match.group(1)
            douyin_=douyin(url)
            video_title=douyin_[0]
            video_url=douyin_[1]
            resp_data = send_douyin_video(access_token, group_openid, video_title, video_url, msg_id,user_id)
            return resp_data

    def handle_robot_join_group(self,json_data):#机器人加入群聊
        """ """

    def handle_robot_leave_group(self,json_data):#机器人退出群聊
        """ """

    def handle_group_push_enable(self,json_data):#群聊消息接收开启
        """ """

    def handle_group_push_disable(self,json_data):#群聊消息接收关闭
        """ """

    def handle_member_join(self,json_data):#群成员加入
        """ """

    def handle_member_leave(self,json_data):#群成员退出
        """ """

    def handle_interaction(self,json_data):#互动事件
        """ """

    def return_data(self,type,json_data):#接口返回数据(json已解析)
        """ """

    def access_token(self,token):#鉴权分发一分钟一次
        """返回要求 返回两个参数 (请求方式,请求地址,请求内容)"""